<?php
// Database setup for Zakho FC
require_once __DIR__ . '/config.php';

// Connect without database first to create it
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database and tables
$conn->query("CREATE DATABASE IF NOT EXISTS zakho_fc");
$conn->select_db("zakho_fc");

// Users table
$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('fan','admin') DEFAULT 'fan',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Matches table
$conn->query("CREATE TABLE IF NOT EXISTS matches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    home_team VARCHAR(100) NOT NULL,
    away_team VARCHAR(100) NOT NULL,
    match_date DATETIME NOT NULL,
    venue VARCHAR(100),
    ticket_price DECIMAL(10,2) DEFAULT 25.00,
    available_tickets INT DEFAULT 1000,
    status ENUM('scheduled','completed') DEFAULT 'scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Products table
$conn->query("CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category ENUM('jersey','scarf','cap','jacket','other') DEFAULT 'other',
    stock INT DEFAULT 0,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Orders table - UPDATED WITH PHONE FIELD
$conn->query("CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    order_type ENUM('ticket','product') NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    shipping_address TEXT,
    phone VARCHAR(20),
    status ENUM('pending','confirmed','shipped','delivered') DEFAULT 'pending',
    payment_method ENUM('cash','card','mobile_payment') DEFAULT 'cash',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Order items table
$conn->query("CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    product_id INT,
    match_id INT,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    item_type ENUM('ticket','product') NOT NULL
)");

// Cart table
$conn->query("CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    item_type ENUM('ticket','product') NOT NULL,
    product_id INT,
    match_id INT,
    quantity INT NOT NULL,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Team Info table
$conn->query("CREATE TABLE IF NOT EXISTS team_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    name_arabic VARCHAR(255),
    founded VARCHAR(50),
    city TEXT,
    stadium VARCHAR(255),
    stadium_opened VARCHAR(50),
    capacity VARCHAR(50),
    league VARCHAR(255),
    nickname VARCHAR(255),
    nickname_arabic VARCHAR(255),
    colors VARCHAR(255),
    status TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)");

// Players table
$conn->query("CREATE TABLE IF NOT EXISTS players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    position VARCHAR(100) NOT NULL,
    number VARCHAR(10),
    nationality VARCHAR(100),
    role TEXT,
    is_special TINYINT(1) DEFAULT 0,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)");

// Stadium Info table
$conn->query("CREATE TABLE IF NOT EXISTS stadium_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    name_kurdish VARCHAR(255),
    location TEXT,
    capacity VARCHAR(100),
    opened_year VARCHAR(50),
    field_size VARCHAR(100),
    description TEXT,
    features TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)");

// Insert sample data
$conn->query("INSERT IGNORE INTO matches (home_team, away_team, match_date, venue, ticket_price, available_tickets) VALUES 
    ('Zakho FC', 'Duhok FC', '2026-03-15 15:00:00', 'Zakho Arena', 25.00, 500),
    ('Zakho FC', 'Newroz FC', '2026-03-22 16:00:00', 'Zakho Arena', 30.00, 750),
    ('Zakho FC', 'Erbil FC', '2026-04-01 14:00:00', 'Zakho Arena', 20.00, 300)
");

$conn->query("INSERT IGNORE INTO products (name, description, price, category, stock) VALUES 
    ('Zakho FC Jersey 2025', 'Official jersey for 2025 season', 59.99, 'jersey', 100),
    ('Team Scarf', 'Official team scarf in club colors', 24.99, 'scarf', 200),
    ('Embroidered Cap', 'Premium embroidered baseball cap', 29.99, 'cap', 150),
    ('Stadium Jacket', 'Waterproof stadium jacket', 79.99, 'other', 75)
");

// Insert default team info
$conn->query("INSERT IGNORE INTO team_info (id, name, name_arabic, founded, city, stadium, stadium_opened, capacity, league, nickname, nickname_arabic, colors, status, description) VALUES 
    (1, 'Zakho Sport Club', 'نادي زاخو الرياضي', '1987', 'Zakho, Duhok Governorate, Kurdistan Region of Iraq', 'Zakho International Stadium', '2021', '~20,000', 'Iraq Stars League (Iraqi Premier League)', 'The Knights of the Frontier', 'فرسان الحدود', 'Yellow and Black', 'Mid-table team in the Iraqi Premier League. Known for being well-organized and tough opponent, especially at their home fortress. Strong support from local community.', 'دەربارەی یانا وەرزشی زاخۆ

یانا وەرزشی زاخۆ، یانەیەکا تۆپا پێنیا پیشەییە ل زاخۆ، ل هەرێما کوردستانێ، عیراقێ.

ئەڤ یانە ل سالا ١٩٨٧ هاتە دامەزراندن و ل بەرزترین ئاستێن تۆپا پێنیا عیراقێ بەشداریێ دکەت.

تیم ب ناڤێ \"فرسان الحدود\" (سوارچاکێن سنۆران) دهێتە ناسین، و ب ڕەنگێن سور و سبي یاریێ دکەت.

یانا زاخۆ خودان مێژوویەکا دەولەمەند و هەوادارێن گەلەک گەرم و شەوقدارە.

ئەڤ یانە ل خولا ئەستێرێن عیراقێ یاریێ دکەت و ل یاریگەها نێڤدەولەتی یا زاخۆ یاریێن خوە دکەت.')
");

// Insert default stadium info
$conn->query("INSERT IGNORE INTO stadium_info (id, name, name_kurdish, location, capacity, opened_year, field_size, description) VALUES 
    (1, 'Zakho International Stadium', 'یاریگای نێودەوڵەتی زاخۆ', 'Zakho, Duhok Governorate, Kurdistan Region of Iraq', '~20,000', '2021', '105m x 68m', 'یاریگای نێودەوڵەتی زاخۆ یاریگایەکی نوێ و پیشەییە کە لە ساڵی ٢٠٢١ کرایەوە.')
");

// Insert default players
$conn->query("INSERT IGNORE INTO players (name, position, number, nationality, role, is_special, display_order) VALUES 
    ('Mohanad Qasim', 'Goalkeeper', '1', 'Iraq', 'Reliable goalkeeper', 0, 1),
    ('Ali Saeed', 'Goalkeeper', '22', 'Iraq', 'Local goalkeeping option', 0, 2),
    ('Hussein Jabbar', 'Defender', '3', 'Iraq', 'Experienced defender', 0, 3),
    ('Haidar Abdul-Raheem', 'Defender', '4', 'Iraq', 'Solid defensive presence', 0, 4),
    ('Hussam Malek', 'Defender', '5', 'Iraq', 'Tough in the back line', 0, 5),
    ('Ali Fayez', 'Defender', '2', 'Iraq', 'Full-back', 0, 6),
    ('Hawar Mulla Mohammed', 'Midfielder', '10', 'Iraq', 'Captain & Legend - Kurdish football legend and Iraqi international', 1, 7),
    ('Amjad Attwan', 'Midfielder', '6', 'Iraq', 'Iraqi international defensive midfielder - Very significant signing', 0, 8),
    ('Mohammed Kalaf', 'Midfielder', '8', 'Iraq', 'Young, talented midfielder', 0, 9),
    ('Youssef Attal', 'Midfielder', '7', 'Iraq', 'Forward/winger in midfield roles', 0, 10),
    ('Ali Raheem', 'Midfielder', '14', 'Iraq', 'Midfield contributor', 0, 11),
    ('Walid Kamil', 'Forward', '9', 'Iraq', 'Pacey forward', 0, 12),
    ('Mustafa Saadoun', 'Forward', '11', 'Iraq', 'Young Iraqi striker', 0, 13),
    ('Karim El Hedoudi', 'Forward', '17', 'Algeria', 'Foreign signing', 0, 14),
    ('Ahmed Hammad', 'Forward', '19', 'Iraq', 'Attacking player', 0, 15)
");

// Insert a default admin user for testing
$conn->query("INSERT IGNORE INTO users (name, username, email, password, role) VALUES 
    ('Admin User', 'admin', 'admin@zakhofc.com', '" . password_hash('admin123', PASSWORD_DEFAULT) . "', 'admin')
");

echo "<h1 style='color: #dc3545; text-align: center;'>✅ Zakho FC Database Ready!</h1>";
echo "<p style='text-align: center;'><a href='index.php' style='color: #dc3545;'>Go to Zakho FC Website</a></p>";
$conn->close();
?>