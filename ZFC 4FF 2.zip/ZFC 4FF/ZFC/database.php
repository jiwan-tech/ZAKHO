<?php
// Auto-fix database schema - Run this ONCE to update your database
// Access via: http://localhost:8888/ZFC%204FF/ZFC/auto_fix_database.php

require_once __DIR__ . '/config.php';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Database Schema Update</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #28a745; background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .error { color: #dc3545; background: #f8d7da; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .info { background: #d1ecf1; padding: 15px; border-radius: 5px; margin: 20px 0; }
        code { background: #f4f4f4; padding: 10px; display: block; border-radius: 3px; margin: 10px 0; }
        .btn { display: inline-block; padding: 10px 20px; background: #dc3545; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Database Schema Update</h1>
        
        <?php
        try {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error . "<br><br><strong>Make sure MAMP MySQL is running!</strong>");
            }

            // Check current ENUM values
            $check_sql = "SHOW COLUMNS FROM products WHERE Field = 'category'";
            $result = $conn->query($check_sql);
            
            if (!$result) {
                throw new Exception("Error checking current schema: " . $conn->error);
            }
            
            $row = $result->fetch_assoc();
            $current_enum = $row['Type'];
            
            echo '<div class="info">';
            echo '<strong>Current category ENUM in database:</strong><br>';
            echo '<code>' . htmlspecialchars($current_enum) . '</code>';
            echo '</div>';

            // Check if 'jacket' is already in the ENUM
            if (strpos($current_enum, "'jacket'") !== false) {
                echo '<div class="success">';
                echo '✅ <strong>Already Updated!</strong><br>';
                echo 'The category "jacket" is already in your database schema. No update needed!';
                echo '</div>';
            } else {
                echo '<div class="info">';
                echo '⚠️ <strong>Update Needed:</strong> The "jacket" category is missing from your database.';
                echo '</div>';
                
                // Update the category ENUM to include 'jacket'
                $sql = "ALTER TABLE products MODIFY COLUMN category ENUM('jersey','scarf','cap','jacket','other') DEFAULT 'other'";

                if ($conn->query($sql) === TRUE) {
                    echo '<div class="success">';
                    echo '✅ <strong>SUCCESS!</strong><br>';
                    echo 'Database updated successfully! Category "jacket" has been added to the products table.';
                    echo '</div>';
                    
                    // Verify the update
                    $verify_result = $conn->query($check_sql);
                    $verify_row = $verify_result->fetch_assoc();
                    echo '<div class="info">';
                    echo '<strong>Updated category ENUM:</strong><br>';
                    echo '<code>' . htmlspecialchars($verify_row['Type']) . '</code>';
                    echo '</div>';
                } else {
                    throw new Exception("Error updating database: " . $conn->error);
                }
            }

            $conn->close();
            
            echo '<div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">';
            echo '<a href="index.php?action=admin" class="btn">← Go to Admin Panel</a>';
            echo '</div>';
            
        } catch (Exception $e) {
            echo '<div class="error">';
            echo '❌ <strong>Error:</strong> ' . $e->getMessage();
            echo '</div>';
            
            echo '<div class="info">';
            echo '<strong>Manual Update Instructions:</strong><br><br>';
            echo '1. Open phpMyAdmin: <a href="http://localhost:8888/phpMyAdmin/" target="_blank">http://localhost:8888/phpMyAdmin/</a><br><br>';
            echo '2. Select the <code>zakho_fc</code> database<br><br>';
            echo '3. Click on the <strong>SQL</strong> tab<br><br>';
            echo '4. Copy and paste this SQL command:<br>';
            echo '<code>ALTER TABLE products MODIFY COLUMN category ENUM(\'jersey\',\'scarf\',\'cap\',\'jacket\',\'other\') DEFAULT \'other\';</code><br><br>';
            echo '5. Click <strong>Go</strong> to execute';
            echo '</div>';
        }
        ?>
    </div>
</body>
</html>

