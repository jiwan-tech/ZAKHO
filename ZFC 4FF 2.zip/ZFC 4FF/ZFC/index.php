<?php
session_start();
require_once 'models/ClubModel.php';
require_once 'views/ClubView.php';
require_once 'controllers/ClubController.php';

// ===== MAIN APPLICATION =====
$controller = new ClubController();
$controller->handleRequest();

?>