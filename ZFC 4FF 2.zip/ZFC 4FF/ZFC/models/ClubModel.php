<?php
require_once __DIR__ . '/../config.php';

class ClubModel {
    private $conn;
    
    public function __construct() {
        $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
        // Set charset to UTF-8
        $this->conn->set_charset("utf8mb4");
    }
    public function isUserAdmin($user_id) {
    $stmt = $this->conn->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    return $user && $user['role'] === 'admin';
}
    
    // ==================== USER METHODS ====================
    public function getUserByEmail($email) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    public function getUserById($user_id) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    public function getUserByUsername($username) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    public function createUser($userData) {
        $stmt = $this->conn->prepare("INSERT INTO users (name, username, email, password) VALUES (?, ?, ?, ?)");
        $hashedPassword = password_hash($userData['password'], PASSWORD_DEFAULT);
        $stmt->bind_param("ssss", $userData['name'], $userData['username'], $userData['email'], $hashedPassword);
        return $stmt->execute();
    }
    
    public function updateUser($user_id, $userData) {
        try {
            if (isset($userData['password'])) {
                // Update with password
                $hashedPassword = password_hash($userData['password'], PASSWORD_DEFAULT);
                $stmt = $this->conn->prepare("UPDATE users SET name = ?, username = ?, email = ?, password = ? WHERE id = ?");
                $stmt->bind_param("ssssi", $userData['name'], $userData['username'], $userData['email'], $hashedPassword, $user_id);
            } else {
                // Update without password
                $stmt = $this->conn->prepare("UPDATE users SET name = ?, username = ?, email = ? WHERE id = ?");
                $stmt->bind_param("sssi", $userData['name'], $userData['username'], $userData['email'], $user_id);
            }
            return $stmt->execute();
        } catch (Exception $e) {
            error_log("Error in updateUser: " . $e->getMessage());
            return false;
        }
    }
    
    public function deleteUser($user_id) {
        try {
            // Start transaction
            $this->conn->begin_transaction();
            
            // Delete user's cart items
            $stmt = $this->conn->prepare("DELETE FROM cart WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            
            // Delete user's orders (or you might want to keep orders for records)
            // For now, we'll just delete the user
            $stmt = $this->conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $result = $stmt->execute();
            
            if ($result) {
                $this->conn->commit();
                return true;
            } else {
                $this->conn->rollback();
                return false;
            }
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("Error in deleteUser: " . $e->getMessage());
            return false;
        }
    }
    
    // ==================== MATCH METHODS ====================
    public function getAllMatches() {
        $result = $this->conn->query("SELECT * FROM matches ORDER BY match_date ASC");
        $matches = [];
        while($row = $result->fetch_assoc()) {
            $matches[] = $row;
        }
        return $matches;
    }
    
    public function getUpcomingMatches($limit = 3) {
        $stmt = $this->conn->prepare("SELECT * FROM matches WHERE match_date >= CURDATE() AND status = 'scheduled' ORDER BY match_date ASC LIMIT ?");
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        $matches = [];
        while($row = $result->fetch_assoc()) {
            $matches[] = $row;
        }
        return $matches;
    }
    
    public function getMatchById($match_id) {
        $stmt = $this->conn->prepare("SELECT * FROM matches WHERE id = ?");
        $stmt->bind_param("i", $match_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    // ==================== PRODUCT METHODS ====================
    public function getAllProducts() {
        $result = $this->conn->query("SELECT * FROM products WHERE status = 'active' ORDER BY created_at DESC");
        $products = [];
        while($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
        return $products;
    }
    
    public function getFeaturedProducts($limit = 4) {
        $stmt = $this->conn->prepare("SELECT * FROM products WHERE status = 'active' ORDER BY created_at DESC LIMIT ?");
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        $products = [];
        while($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
        return $products;
    }
    
    public function getProductById($product_id) {
        $stmt = $this->conn->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    // ==================== CART METHODS ====================
    public function addToCart($user_id, $item_type, $product_id = null, $match_id = null, $quantity = 1) {
        try {
            // Check if item already in cart
            $check_stmt = $this->conn->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND item_type = ? AND product_id = ? AND match_id = ?");
            // Handle NULL values properly
            $check_stmt->bind_param("isii", $user_id, $item_type, $product_id, $match_id);
            $check_stmt->execute();
            $existing = $check_stmt->get_result()->fetch_assoc();
            
            if ($existing) {
                // Update quantity
                $update_stmt = $this->conn->prepare("UPDATE cart SET quantity = quantity + ? WHERE id = ?");
                $update_stmt->bind_param("ii", $quantity, $existing['id']);
                return $update_stmt->execute();
            } else {
                // Add new item - handle NULL values properly
                $stmt = $this->conn->prepare("INSERT INTO cart (user_id, item_type, product_id, match_id, quantity) VALUES (?, ?, ?, ?, ?)");
                
                // Convert empty values to NULL for database
                $product_id = $product_id ?: NULL;
                $match_id = $match_id ?: NULL;
                
                $stmt->bind_param("isiii", $user_id, $item_type, $product_id, $match_id, $quantity);
                $result = $stmt->execute();
                
                if (!$result) {
                    error_log("Cart insert error: " . $stmt->error);
                    return false;
                }
                return $result;
            }
        } catch (Exception $e) {
            error_log("Error in addToCart: " . $e->getMessage());
            return false;
        }
    }
    
    public function getCartItems($user_id) {
        $stmt = $this->conn->prepare("
            SELECT c.*, 
                   p.name as product_name, p.price as product_price, p.stock as product_stock,
                   m.home_team, m.away_team, m.match_date, m.venue, m.ticket_price
            FROM cart c 
            LEFT JOIN products p ON c.product_id = p.id 
            LEFT JOIN matches m ON c.match_id = m.id 
            WHERE c.user_id = ?
            ORDER BY c.added_at DESC
        ");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $items = [];
        while($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
        return $items;
    }
    
    public function updateCartItem($cart_id, $quantity) {
        if ($quantity <= 0) {
            return $this->removeFromCart($cart_id);
        }
        
        $stmt = $this->conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
        $stmt->bind_param("ii", $quantity, $cart_id);
        return $stmt->execute();
    }
    
    public function removeFromCart($cart_id) {
        $stmt = $this->conn->prepare("DELETE FROM cart WHERE id = ?");
        $stmt->bind_param("i", $cart_id);
        return $stmt->execute();
    }
    
    public function clearCart($user_id) {
        $stmt = $this->conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        return $stmt->execute();
    }
    
    // ==================== ORDER METHODS ====================
    public function createOrder($user_id, $order_type, $total_amount, $shipping_address, $phone, $payment_method = 'cash', $items, $selected_cart_ids = []) {
        // Start transaction
        $this->conn->begin_transaction();
        
        try {
            // Create order with phone number and payment method
            $order_stmt = $this->conn->prepare("INSERT INTO orders (user_id, order_type, total_amount, shipping_address, phone, payment_method) VALUES (?, ?, ?, ?, ?, ?)");
            $order_stmt->bind_param("isdsss", $user_id, $order_type, $total_amount, $shipping_address, $phone, $payment_method);
            $order_stmt->execute();
            $order_id = $this->conn->insert_id;
            
            // Add order items
            foreach ($items as $item) {
                $item_stmt = $this->conn->prepare("INSERT INTO order_items (order_id, product_id, match_id, quantity, unit_price, item_type) VALUES (?, ?, ?, ?, ?, ?)");
                
                // Handle NULL values
                $product_id = $item['product_id'] ?: NULL;
                $match_id = $item['match_id'] ?: NULL;
                
                $item_stmt->bind_param("iiidis", $order_id, $product_id, $match_id, $item['quantity'], $item['unit_price'], $item['item_type']);
                $item_stmt->execute();
                
                // Update product stock if it's a product
                if ($item['item_type'] == 'product' && $item['product_id']) {
                    $update_stmt = $this->conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
                    $update_stmt->bind_param("ii", $item['quantity'], $item['product_id']);
                    $update_stmt->execute();
                }
                
                // Update available tickets if it's a ticket
                if ($item['item_type'] == 'ticket' && $item['match_id']) {
                    $update_stmt = $this->conn->prepare("UPDATE matches SET available_tickets = available_tickets - ? WHERE id = ?");
                    $update_stmt->bind_param("ii", $item['quantity'], $item['match_id']);
                    $update_stmt->execute();
                }
            }
            
            // Clear only selected items from cart, or all if no selection specified
            if (!empty($selected_cart_ids)) {
                $this->clearSelectedCartItems($selected_cart_ids);
            } else {
                $this->clearCart($user_id);
            }
            
            // Commit transaction
            $this->conn->commit();
            return $order_id;
            
        } catch (Exception $e) {
            $this->conn->rollback();
            error_log("Error in createOrder: " . $e->getMessage());
            return false;
        }
    }
    
    public function clearSelectedCartItems($cart_ids) {
        if (empty($cart_ids)) {
            return false;
        }
        
        $placeholders = str_repeat('?,', count($cart_ids) - 1) . '?';
        $stmt = $this->conn->prepare("DELETE FROM cart WHERE id IN ($placeholders)");
        $types = str_repeat('i', count($cart_ids));
        $stmt->bind_param($types, ...$cart_ids);
        return $stmt->execute();
    }
    
    public function getUserOrders($user_id) {
        $stmt = $this->conn->prepare("
            SELECT o.*, 
                   GROUP_CONCAT(CONCAT(oi.quantity, 'x ', 
                     CASE 
                       WHEN oi.item_type = 'product' THEN p.name 
                       WHEN oi.item_type = 'ticket' THEN CONCAT(m.home_team, ' vs ', m.away_team)
                     END
                   ) SEPARATOR ', ') as items
            FROM orders o 
            LEFT JOIN order_items oi ON o.id = oi.order_id 
            LEFT JOIN products p ON oi.product_id = p.id 
            LEFT JOIN matches m ON oi.match_id = m.id 
            WHERE o.user_id = ?
            GROUP BY o.id
            ORDER BY o.created_at DESC
        ");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $orders = [];
        while($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
        return $orders;
    }
}
?>