<?php
// Database Configuration for Zakho FC
// Update these values according to your MAMP/MySQL setup

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'root'); // MAMP default password is 'root', change if different
define('DB_NAME', 'zakho_fc');

// You can also use environment variables for better security:
// define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
// define('DB_USER', getenv('DB_USER') ?: 'root');
// define('DB_PASS', getenv('DB_PASS') ?: 'root');
// define('DB_NAME', getenv('DB_NAME') ?: 'zakho_fc');
?>

