<?php
// Script to create team_info, players, and stadium_info tables
require_once __DIR__ . '/config.php';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

echo "<h2>Creating Management Tables...</h2>";

// Team Info table
$sql = "CREATE TABLE IF NOT EXISTS team_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    name_arabic VARCHAR(255),
    founded VARCHAR(50),
    city TEXT,
    stadium VARCHAR(255),
    stadium_opened VARCHAR(50),
    capacity VARCHAR(50),
    league VARCHAR(255),
    nickname VARCHAR(255),
    nickname_arabic VARCHAR(255),
    colors VARCHAR(255),
    status TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color:green;'>✓ team_info table created</p>";
} else {
    echo "<p style='color:red;'>✗ Error creating team_info: " . $conn->error . "</p>";
}

// Players table
$sql = "CREATE TABLE IF NOT EXISTS players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    position VARCHAR(100) NOT NULL,
    number VARCHAR(10),
    nationality VARCHAR(100),
    role TEXT,
    is_special TINYINT(1) DEFAULT 0,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color:green;'>✓ players table created</p>";
} else {
    echo "<p style='color:red;'>✗ Error creating players: " . $conn->error . "</p>";
}

// Stadium Info table
$sql = "CREATE TABLE IF NOT EXISTS stadium_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    name_kurdish VARCHAR(255),
    location TEXT,
    capacity VARCHAR(100),
    opened_year VARCHAR(50),
    field_size VARCHAR(100),
    description TEXT,
    features TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color:green;'>✓ stadium_info table created</p>";
} else {
    echo "<p style='color:red;'>✗ Error creating stadium_info: " . $conn->error . "</p>";
}

// Insert default team info if table is empty
$result = $conn->query("SELECT COUNT(*) as count FROM team_info");
$row = $result->fetch_assoc();
if ($row['count'] == 0) {
    $sql = "INSERT INTO team_info (id, name, name_arabic, founded, city, stadium, stadium_opened, capacity, league, nickname, nickname_arabic, colors, status, description) VALUES 
    (1, 'Zakho Sport Club', 'نادي زاخو الرياضي', '1987', 'Zakho, Duhok Governorate, Kurdistan Region of Iraq', 'Zakho International Stadium', '2021', '~20,000', 'Iraq Stars League (Iraqi Premier League)', 'The Knights of the Frontier', 'فرسان الحدود', 'Yellow and Black', 'Mid-table team in the Iraqi Premier League. Known for being well-organized and tough opponent, especially at their home fortress. Strong support from local community.', 'دەربارەی یانا وەرزشی زاخۆ

یانا وەرزشی زاخۆ، یانەیەکا تۆپا پێنیا پیشەییە ل زاخۆ، ل هەرێما کوردستانێ، عیراقێ.

ئەڤ یانە ل سالا ١٩٨٧ هاتە دامەزراندن و ل بەرزترین ئاستێن تۆپا پێنیا عیراقێ بەشداریێ دکەت.

تیم ب ناڤێ \"فرسان الحدود\" (سوارچاکێن سنۆران) دهێتە ناسین، و ب ڕەنگێن سور و سبي یاریێ دکەت.

یانا زاخۆ خودان مێژوویەکا دەولەمەند و هەوادارێن گەلەک گەرم و شەوقدارە.

ئەڤ یانە ل خولا ئەستێرێن عیراقێ یاریێ دکەت و ل یاریگەها نێڤدەولەتی یا زاخۆ یاریێن خوە دکەت.')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>✓ Default team info inserted</p>";
    } else {
        echo "<p style='color:red;'>✗ Error inserting team info: " . $conn->error . "</p>";
    }
}

// Insert default stadium info if table is empty
$result = $conn->query("SELECT COUNT(*) as count FROM stadium_info");
$row = $result->fetch_assoc();
if ($row['count'] == 0) {
    $sql = "INSERT INTO stadium_info (id, name, name_kurdish, location, capacity, opened_year, field_size, description) VALUES 
    (1, 'Zakho International Stadium', 'یاریگای نێودەوڵەتی زاخۆ', 'Zakho, Duhok Governorate, Kurdistan Region of Iraq', '~20,000', '2021', '105m x 68m', 'یاریگای نێودەوڵەتی زاخۆ یاریگایەکی نوێ و پیشەییە کە لە ساڵی ٢٠٢١ کرایەوە.')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>✓ Default stadium info inserted</p>";
    } else {
        echo "<p style='color:red;'>✗ Error inserting stadium info: " . $conn->error . "</p>";
    }
}

// Insert default players if table is empty
$result = $conn->query("SELECT COUNT(*) as count FROM players");
$row = $result->fetch_assoc();
if ($row['count'] == 0) {
    $sql = "INSERT INTO players (name, position, number, nationality, role, is_special, display_order) VALUES 
    ('Mohanad Qasim', 'Goalkeeper', '1', 'Iraq', 'Reliable goalkeeper', 0, 1),
    ('Ali Saeed', 'Goalkeeper', '22', 'Iraq', 'Local goalkeeping option', 0, 2),
    ('Hussein Jabbar', 'Defender', '3', 'Iraq', 'Experienced defender', 0, 3),
    ('Haidar Abdul-Raheem', 'Defender', '4', 'Iraq', 'Solid defensive presence', 0, 4),
    ('Hussam Malek', 'Defender', '5', 'Iraq', 'Tough in the back line', 0, 5),
    ('Ali Fayez', 'Defender', '2', 'Iraq', 'Full-back', 0, 6),
    ('Hawar Mulla Mohammed', 'Midfielder', '10', 'Iraq', 'Captain & Legend - Kurdish football legend and Iraqi international', 1, 7),
    ('Amjad Attwan', 'Midfielder', '6', 'Iraq', 'Iraqi international defensive midfielder - Very significant signing', 0, 8),
    ('Mohammed Kalaf', 'Midfielder', '8', 'Iraq', 'Young, talented midfielder', 0, 9),
    ('Youssef Attal', 'Midfielder', '7', 'Iraq', 'Forward/winger in midfield roles', 0, 10),
    ('Ali Raheem', 'Midfielder', '14', 'Iraq', 'Midfield contributor', 0, 11),
    ('Walid Kamil', 'Forward', '9', 'Iraq', 'Pacey forward', 0, 12),
    ('Mustafa Saadoun', 'Forward', '11', 'Iraq', 'Young Iraqi striker', 0, 13),
    ('Karim El Hedoudi', 'Forward', '17', 'Algeria', 'Foreign signing', 0, 14),
    ('Ahmed Hammad', 'Forward', '19', 'Iraq', 'Attacking player', 0, 15)";
    
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>✓ Default players inserted</p>";
    } else {
        echo "<p style='color:red;'>✗ Error inserting players: " . $conn->error . "</p>";
    }
}

echo "<h3 style='color:green;'>✅ All tables created successfully!</h3>";
echo "<p><a href='index.php?action=admin'>Go to Admin Panel</a></p>";

$conn->close();
?>
