// Cart functionality for Zakho FC
function addToCart(itemType, productId = null, matchId = null, quantity = 1) {
    // Check if user is logged in
    if (!isLoggedIn()) {
        alert('Please login to add items to cart');
        window.location.href = 'index.php?action=signin';
        return;
    }

    const formData = new FormData();
    formData.append('item_type', itemType);
    if (productId) formData.append('product_id', productId);
    if (matchId) formData.append('match_id', matchId);
    formData.append('quantity', quantity);

    // Show loading state
    const button = event.target;
    const originalText = button.innerHTML;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
    button.disabled = true;

    fetch('index.php?action=add_to_cart', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log('Response data:', data); // Debug log
        if (data.success) {
            showAlert('Item added to cart!', 'success');
            updateCartCounter();
        } else {
            showAlert(data.message || 'Failed to add item', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('Error adding item to cart. Please try again.', 'error');
    })
    .finally(() => {
        // Restore button state
        button.innerHTML = originalText;
        button.disabled = false;
    });
}

function isLoggedIn() {
    return typeof isUserLoggedIn !== 'undefined' && isUserLoggedIn;
}

function showAlert(message, type = 'info') {
    const alertClass = type === 'success' ? 'alert-success' : 
                      type === 'error' ? 'alert-danger' : 'alert-info';
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert ${alertClass} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        <strong>${type === 'success' ? 'Success!' : type === 'error' ? 'Error!' : 'Info!'}</strong> ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 3000);
}

function updateCartCounter() {
    // Fetch actual cart count from server
    fetch('index.php?action=get_cart_count')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Cart count data:', data); // Debug log
            if (data.success) {
                const cartCounter = document.getElementById('cart-counter');
                if (cartCounter) {
                    cartCounter.textContent = data.count;
                    // If count is 0, hide the badge
                    if (data.count === 0) {
                        cartCounter.style.display = 'none';
                    } else {
                        cartCounter.style.display = 'inline';
                    }
                }
            }
        })
        .catch(error => {
            console.error('Error fetching cart count:', error);
        });
}

// Cart management functions
function updateQuantity(cartId, newQuantity) {
    if (newQuantity < 1) return;
    
    fetch("index.php?action=update_cart", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: "cart_id=" + cartId + "&quantity=" + newQuantity
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            showAlert(data.message || 'Failed to update quantity', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('Error updating quantity', 'error');
    });
}

function removeFromCart(cartId) {
    if (confirm("Are you sure you want to remove this item?")) {
        fetch("index.php?action=remove_from_cart", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: "cart_id=" + cartId
        })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            const itemElement = document.getElementById("cart-item-" + cartId);
            if (itemElement) {
                itemElement.remove();
            }
            showAlert('Item removed from cart', 'success');
            updateCartCounter();
            // Reload to update totals after a short delay
            setTimeout(() => {
                // Only reload if we're on the cart page
                if (window.location.href.includes('action=cart')) {
                    location.reload();
                }
            }, 1000);
        } else {
            showAlert(data.message || 'Failed to remove item', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('Error removing item', 'error');
    });
    }
}

function placeOrder() {
    console.log('placeOrder function called'); // Debug log
    
    // Find the form - use multiple methods
    let form = document.getElementById("checkout-form");
    if (!form) {
        // Alternative: look for any form that might be the checkout form
        form = document.querySelector('form');
        if (!form) {
            console.error('No form found on page');
            showAlert('Checkout form not found', 'error');
            return;
        }
    }
    
    const shippingAddress = form.querySelector('[name="shipping_address"]');
    const phone = form.querySelector('[name="phone"]');
    
    if (!shippingAddress) {
        console.error('Shipping address field not found');
        showAlert('Shipping address field not found', 'error');
        return;
    }
    
    if (!phone) {
        console.error('Phone field not found');
        showAlert('Phone field not found', 'error');
        return;
    }
    
    const addressValue = shippingAddress.value.trim();
    const phoneValue = phone.value.trim();
    
    if (!addressValue) {
        showAlert('Please enter shipping address', 'error');
        shippingAddress.focus();
        return;
    }
    
    if (!phoneValue) {
        showAlert('Please enter phone number', 'error');
        phone.focus();
        return;
    }
    
    // Find the button - SIMPLIFIED APPROACH
    let button = document.querySelector('button[onclick="placeOrder()"]');
    if (!button) {
        // Alternative: find any button with "Place Order" text
        const buttons = document.querySelectorAll('button');
        button = Array.from(buttons).find(btn => 
            btn.textContent.includes('Place Order') || 
            btn.textContent.includes('place order')
        );
    }
    
    if (!button) {
        console.error('Place Order button not found');
        showAlert('Place Order button not found', 'error');
        return;
    }
    
    const formData = new FormData(form);
    const originalText = button.innerHTML;
    
    // Show loading
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    button.disabled = true;
    
    console.log('Sending order request...'); // Debug log
    
    fetch("index.php?action=process_order", {
        method: "POST",
        body: formData
    })
    .then(response => {
        console.log('Response received:', response); // Debug log
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.status);
        }
        return response.json();
    })
    .then(data => {
        console.log('Order response data:', data); // Debug log
        if (data.success) {
            showAlert("Order placed successfully! Your order ID: " + data.order_id, 'success');
            // Redirect to orders page after success
            setTimeout(() => {
                window.location.href = "index.php?action=orders";
            }, 2000);
        } else {
            showAlert("Error: " + (data.message || 'Unknown error occurred'), 'error');
            button.innerHTML = originalText;
            button.disabled = false;
        }
    })
    .catch(error => {
        console.error('Error processing order:', error);
        showAlert("Error processing order: " + error.message, 'error');
        button.innerHTML = originalText;
        button.disabled = false;
    });
}

// Initialize cart functionality when page loads
document.addEventListener('DOMContentLoaded', function() {
    updateCartCounter();
    console.log('Zakho FC cart system loaded');
});