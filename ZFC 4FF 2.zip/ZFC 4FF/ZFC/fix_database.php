<?php
// Quick database fix script - Run this in your browser
// URL: http://localhost:8888/ZFC%204FF/ZFC/fix_database.php

require_once __DIR__ . '/config.php';

echo "<h2>Updating Database Schema...</h2>";

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error . "<br><br>Make sure MAMP MySQL is running!");
}

// Update the category ENUM to include 'jacket'
$sql = "ALTER TABLE products MODIFY COLUMN category ENUM('jersey','scarf','cap','jacket','other') DEFAULT 'other'";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color:green;'><strong>✓ SUCCESS!</strong> Database updated. 'jacket' category has been added.</p>";
    echo "<p>You can now use 'jacket' as a product category.</p>";
    echo "<p><a href='index.php?action=admin'>Go to Admin Panel</a></p>";
} else {
    echo "<p style='color:red;'><strong>✗ ERROR:</strong> " . $conn->error . "</p>";
    echo "<p>Try running this SQL manually in phpMyAdmin:</p>";
    echo "<pre>ALTER TABLE products MODIFY COLUMN category ENUM('jersey','scarf','cap','jacket','other') DEFAULT 'other';</pre>";
}

$conn->close();
?>

