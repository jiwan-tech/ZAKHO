-- Update products table to add 'jacket' category
ALTER TABLE products MODIFY COLUMN category ENUM('jersey','scarf','cap','jacket','other') DEFAULT 'other';

