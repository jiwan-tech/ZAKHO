<?php

class AdminView {

    /* ------------------------------
       ADMIN DASHBOARD
    ------------------------------ */
    public function showAdminDashboard($matches, $products, $orders) {

        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>Admin Dashboard</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body class="bg-light">

        <div class="container mt-5">
            <h1 class="text-center mb-4">Admin Dashboard</h1>

            <div class="row">

                <div class="col-md-4">
                    <a class="btn btn-danger w-100 mb-3" href="admin.php?action=add_match">Add Match</a>
                </div>

                <div class="col-md-4">
                    <a class="btn btn-danger w-100 mb-3" href="admin.php?action=add_product">Add Product</a>
                </div>

                <div class="col-md-4">
                    <a class="btn btn-dark w-100 mb-3" href="admin.php?action=view_orders">View Orders</a>
                </div>

            </div>

        </div>

        </body>
        </html>';
    }



    /* ------------------------------
       MATCH FORM (ADD/EDIT)
    ------------------------------ */
    public function matchForm($match = null) {

        $isEdit = $match !== null;
        $title = $isEdit ? "Edit Match" : "Add Match";
        $action = $isEdit
            ? "admin.php?action=update_match&id=".$match["id"]
            : "admin.php?action=insert_match";

        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>'.$title.'</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>

        <body class="bg-light">

        <div class="container mt-5">
            <div class="card shadow">
                <div class="card-header bg-danger text-white">'.$title.'</div>

                <div class="card-body">

                    <form action="'.$action.'" method="POST">

                        <div class="mb-3">
                            <label>Home Team</label>
                            <input type="text" class="form-control" name="home_team"
                                   value="'.($match["home_team"] ?? "").'" required>
                        </div>

                        <div class="mb-3">
                            <label>Away Team</label>
                            <input type="text" class="form-control" name="away_team"
                                   value="'.($match["away_team"] ?? "").'" required>
                        </div>

                        <div class="mb-3">
                            <label>Match Date</label>
                            <input type="datetime-local" class="form-control" name="match_date"
                                   value="'.($match ? date("Y-m-d\TH:i", strtotime($match["match_date"])) : "").'" required>
                        </div>

                        <div class="mb-3">
                            <label>Venue</label>
                            <input type="text" class="form-control" name="venue"
                                   value="'.($match["venue"] ?? "").'">
                        </div>

                        <button class="btn btn-danger">Save</button>
                        <a href="admin.php" class="btn btn-secondary">Cancel</a>
                    </form>

                </div>
            </div>
        </div>

        </body>
        </html>';
    }



    /* ------------------------------
       PRODUCT FORM (ADD/EDIT)
    ------------------------------ */
    public function productForm($product = null) {

        $isEdit = $product !== null;
        $title = $isEdit ? "Edit Product" : "Add Product";
        $action = $isEdit
            ? "admin.php?action=update_product&id=".$product["id"]
            : "admin.php?action=insert_product";

        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>'.$title.'</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>

        <body class="bg-light">

        <div class="container mt-5">
            <div class="card shadow">
                <div class="card-header bg-danger text-white">'.$title.'</div>

                <div class="card-body">

                    <form action="'.$action.'" method="POST" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label>Product Name</label>
                            <input type="text" class="form-control" name="name"
                                   value="'.($product["name"] ?? "").'" required>
                        </div>

                        <div class="mb-3">
                            <label>Description</label>
                            <textarea class="form-control" name="description">'.($product["description"] ?? "").'</textarea>
                        </div>

                        <div class="mb-3">
                            <label>Price</label>
                            <input type="number" class="form-control" step="0.01" name="price"
                                   value="'.($product["price"] ?? "").'" required>
                        </div>

                        <div class="mb-3">
                            <label>Stock</label>
                            <input type="number" class="form-control" name="stock"
                                   value="'.($product["stock"] ?? "").'" required>
                        </div>

                        <div class="mb-3">
                            <label>Image</label>';
                            if ($isEdit && !empty($product["image"])) {
                                echo '<br><img src="img/products/'.$product["image"].'" width="120"><br><br>';
                            }
        echo '
                            <input type="file" class="form-control" name="image">
                        </div>

                        <button class="btn btn-danger">Save</button>
                        <a href="admin.php" class="btn btn-secondary">Cancel</a>
                    </form>

                </div>
            </div>
        </div>

        </body>
        </html>';
    }



    /* ------------------------------
       ORDER STATUS FORM
    ------------------------------ */
    public function editOrderStatus($order) {

        echo '
        <!DOCTYPE html>
        <html>
        <head>
            <title>Edit Order Status</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>

        <body class="bg-light">

        <div class="container mt-5">

            <div class="card shadow">
                <div class="card-header bg-dark text-white">Edit Order #'.$order["id"].'</div>

                <div class="card-body">

                    <form method="POST" action="admin.php?action=update_order_status&id='.$order["id"].'">

                        <div class="mb-3">
                            <label>Status</label>
                            <select class="form-select" name="status">
                                <option value="pending" '.($order["status"]=="pending"?"selected":"").'>Pending</option>
                                <option value="confirmed" '.($order["status"]=="confirmed"?"selected":"").'>Confirmed</option>
                                <option value="shipped" '.($order["status"]=="shipped"?"selected":"").'>Shipped</option>
                                <option value="delivered" '.($order["status"]=="delivered"?"selected":"").'>Delivered</option>
                            </select>
                        </div>

                        <button class="btn btn-dark">Update</button>
                        <a href="admin.php" class="btn btn-secondary">Cancel</a>

                    </form>

                </div>
            </div>

        </div>

        </body>
        </html>';
    }
}
?>
