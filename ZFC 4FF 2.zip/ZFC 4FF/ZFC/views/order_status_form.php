<?php
class AdminView {

    public function editOrderStatus($order) {

        echo '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Edit Order Status</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>

        <body class="bg-light">

        <div class="container mt-5">

            <div class="card shadow-lg">
                <div class="card-header bg-dark text-white">
                    <h3>Edit Order #'.$order["id"].'</h3>
                </div>

                <div class="card-body">

                    <form action="admin.php?action=update_order_status&id='.$order["id"].'" method="POST">

                        <div class="mb-3">
                            <label class="form-label">Status</label>

                            <select name="status" class="form-select" required>
                                <option value="pending" '.($order["status"]=="pending"?"selected":"").'>Pending</option>
                                <option value="paid" '.($order["status"]=="paid"?"selected":"").'>Paid</option>
                                <option value="shipped" '.($order["status"]=="shipped"?"selected":"").'>Shipped</option>
                                <option value="completed" '.($order["status"]=="completed"?"selected":"").'>Completed</option>
                                <option value="canceled" '.($order["status"]=="canceled"?"selected":"").'>Canceled</option>
                            </select>
                        </div>

                        <button class="btn btn-dark px-4">Update Status</button>
                        <a href="admin.php" class="btn btn-secondary">Cancel</a>

                    </form>

                </div>
            </div>

        </div>

        </body>
        </html>';
    }
}
?>
