<?php
class ClubView {
    
    private function translateStatus($status) {
        $translations = [
            'pending' => 'چاوەڕوان',
            'confirmed' => 'دڵنیاکراوەتەوە',
            'shipped' => 'نێردراوە',
            'delivered' => 'گەیشتووە'
        ];
        return $translations[$status] ?? ucfirst($status);
    }
    
    private function translatePaymentMethod($method) {
        $translations = [
            'cash' => 'پارەدان لە کاتی وەرگرتندا',
            'card' => 'کارتا بانکی',
            'mobile_payment' => 'پارەدانا مۆبایل'
        ];
        return $translations[$method] ?? ucfirst(str_replace('_', ' ', $method));
    }
    
    private function translateOrderType($type) {
        $translations = [
            'ticket' => 'بلیت',
            'product' => 'کاڵا'
        ];
        return $translations[$type] ?? ucfirst($type);
    }
    
    private function translateCategory($category) {
        $translations = [
            'jersey' => 'جێرسی',
            'scarf' => 'شاڵ',
            'cap' => 'کڵاف',
            'other' => 'ئەویتر'
        ];
        return $translations[$category] ?? ucfirst($category);
    }
    
    public function showHomepage($upcoming_matches, $featured_products, $all_products = [], $user = null) {
        echo '<!DOCTYPE html>
        <html lang="ku" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>ياريگه هـا زاخۆ - کلووبی فەرمی</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
        </head>
        <body>
            <!-- Navigation -->
            <nav class="navbar navbar-expand-lg navbar-dark bg-red professional-navbar">
                <div class="container">
                   <a class="navbar-brand" href="index.php">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" class="navbar-logo">
                        <div class="club-logo">
                            <span class="logo-text">ZAKHO</span>
                            <small>FC</small>
                        </div>
                    </a>
                            
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    
                    <div class="collapse navbar-collapse" id="navbarContent">
                        <!-- Main Navigation Links -->
                        <ul class="navbar-nav main-nav">
                        <li class="nav-item">
                                <a class="nav-link" href="index.php">
                                    <i class="fas fa-home"></i> سەرەکی
                                </a>
</li>
                            <li class="nav-item">
                                <a class="nav-link" href="#matches">
                                    <i class="fas fa-calendar-alt"></i> یاری
                                </a>
                            </li>';
                            
                            // Hide shop link for admin
                            if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
                                echo '<li class="nav-item">
                                    <a class="nav-link" href="#shop">
                                        <i class="fas fa-shopping-bag"></i> فروشگە
                                    </a>
                                </li>';
                            }
                            
                            echo '<li class="nav-item">
                                <a class="nav-link" href="index.php?action=team">
                                    <i class="fas fa-users"></i> تیم
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php?action=stadium">
                                    <i class="fas fa-stadium"></i> یاریگا
                                </a>
                            </li>
                        </ul>
                        
                        <!-- Right Side Actions -->
                        <ul class="navbar-nav nav-actions">';
                            
                            // Admin Panel (if admin) - Show first for admins
if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin') {
                                echo '<li class="nav-item">
                                    <a class="nav-link" href="index.php?action=admin">
                                        <i class="fas fa-cog"></i> پانێلی بەڕێوەبردن
                                    </a>
                                </li>';
                            } else {
                                // Hide cart for admin
                                echo '<li class="nav-item">
                                    <a class="nav-link cart-link" href="index.php?action=cart">
                                        <i class="fas fa-shopping-cart"></i>
                                        <span class="cart-text">سەبەتە</span>
                                        <span id="cart-counter" class="badge bg-light text-red cart-badge">0</span>
                                    </a>
                                </li>';
                            }
                            
                            // User Account Dropdown
                        if ($user) {
                                echo '<li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle user-dropdown" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fas fa-user-circle"></i>
                                        <span class="user-name">' . htmlspecialchars($user['name']) . '</span>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                        <li>
                                            <a class="dropdown-item" href="index.php?action=account">
                                                <i class="fas fa-user-circle"></i> هەژمارا من
                                            </a>
                                        </li>';
                                        
                                        // Hide orders link for admin (they manage orders from admin panel)
                                        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
                                            echo '<li>
                                            <a class="dropdown-item" href="index.php?action=orders">
                                                <i class="fas fa-receipt"></i> داخازی
                                            </a>
                                        </li>';
                                        }
                                        
                                        echo '<li><hr class="dropdown-divider"></li>
                                        <li>
                                            <a class="dropdown-item text-danger" href="index.php?action=logout">
                                                <i class="fas fa-sign-out-alt"></i> دەرچوون
                                            </a>
                                        </li>
                                    </ul>
                                </li>';
                        } else {
                                echo '<li class="nav-item">
                                    <a class="nav-link" href="index.php?action=signin">
                                        <i class="fas fa-sign-in-alt"></i> چووناژوور
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link btn-signup" href="index.php?action=signup">
                                        خۆتۆمارکردن
                                    </a>
                                </li>';
                            }
                            
                        echo '</ul>
                    </div>
                </div>
            </nav>

                <!-- Hero Section -->
        <section class="hero" style="background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.6)), url(\'img/image.png\');">
            <div class="hero-content">
                <h1>Zakho FC</h1>
                <div class="hero-subtitle">شانازيا كوردستانێ  </div>
                <p class="hero-description">
                    پشكداربه د رەوشا تەپا پێ ل یاریگەها زاخۆ، پشکداڕبە دگەل هزاران شتەڤانێن دلسۆز یێن پشتگیریا یانا خۆ دکەن د هەمی یاریا دا، نوکە پلێتا خو و جل و بەرگێن فه رمی بکڕە.
                </p>
                
                <div class="cta-buttons">
                    <a href="#matches" class="btn btn-primary">
                        <i class="fas fa-ticket-alt"></i>
                        پلێت بکڕە
                    </a>';
                    
                    // Hide shop button for admin
                    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
                        echo '<a href="#shop" class="btn btn-secondary">
                        <i class="fas fa-shopping-bag"></i>
                       فروشگەها تیمێ
                    </a>';
                    }
                    
                    echo '</div>

                <!-- Stats Section -->
                <div class="stats">
                    <div class="stat-item">
                        <span class="stat-number">15K+</span>
                        <span class="stat-label">پشتەڤانێن دلسوز</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">50+</span>
                        <span class="stat-label">یاریێن هاتین کرن
</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">12</span>
                        <span class="stat-label"> سەرکەفتن</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">25+</span>
                        <span class="stat-label"> ئەندامێن تیمێ</span>
                    </div>
                </div>
            </div>

            <!-- Scroll Indicator -->
            <div class="scroll-indicator">
                <div class="scroll-arrow"></div>
            </div>
        </section>

            <!-- Upcoming Matches -->
            <section id="matches" class="py-5">
                <div class="container">
                    <h2 class="section-title text-center mb-5">یاریێن بهێت </h2>
                    <div class="row">';
        
        foreach($upcoming_matches as $match) {
            $match_date = date('M j, Y', strtotime($match['match_date']));
            $match_time = date('g:i A', strtotime($match['match_date']));
            
            echo '<div class="col-md-4 mb-4">
                    <div class="match-card">
                        <div class="match-header">
                            <div class="match-date">' . $match_date . '</div>
                            <div class="match-time">' . $match_time . '</div>
                        </div>
                        <div class="match-teams">
                            <div class="team home-team">
                                <strong>' . htmlspecialchars($match['home_team']) . '</strong>
                            </div>
                            <div class="vs">بەرامبەر</div>
                            <div class="team away-team">
                                <strong>' . htmlspecialchars($match['away_team']) . '</strong>
                            </div>
                        </div>
                        <div class="match-venue">
                            <i class="fas fa-map-marker-alt"></i> ' . htmlspecialchars($match['venue']) . '
                        </div>
                        <div class="match-price">
                            <strong>$' . number_format($match['ticket_price'], 2) . ' per ticket</strong>
                        </div>
                        <div class="match-actions">';
                            
                            // Hide cart button for admin
                            if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
                                echo '<button onclick="addToCart(\'ticket\', null, ' . $match['id'] . ', 1)" class="btn btn-red">
                                <i class="fas fa-ticket-alt"></i>  پلێت بکڕە
                            </button>';
                            }
                            
                            echo '</div>
                    </div>
                  </div>';
        }
        
        echo '</div>
                </div>
            </section>

            <!-- Club Shop -->
            ';
            
            // Hide shop section for admin
            if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
                echo '<section id="shop" class="py-5 bg-light">
                <div class="container">
                    <h2 class="section-title text-center mb-5"> فروشگەها تیمێ
 </h2>
                    <div class="products-carousel-wrapper">
                        <button class="carousel-btn carousel-btn-left" onclick="scrollProducts(-1)">
                            <i class="fas fa-chevron-left"></i>
                        </button>
                        <div class="products-carousel" id="productsCarousel">
                            <div class="products-container">';
        
        $product_idx = 0;
        $jersey_count = 0; // Track jersey count separately
        foreach($all_products as $product) {
            $short_desc = strlen($product['description']) > 80 ? substr($product['description'], 0, 80) . '...' : $product['description'];
            
            // Determine image based on product category - each product gets unique image
            $cache_buster = '?v=' . time() . '&id=' . $product['id'];
            $product_image = 'img/3_P_Logo.png' . $cache_buster; // Default
            
            if ($product['category'] == 'jersey') {
                // Use jersey images - alternate between red and white based on jersey count
                $product_image = ($jersey_count % 2 == 0) ? 'img/jersey_red.png' . $cache_buster : 'img/jersey_white.png' . $cache_buster;
                $jersey_count++; // Increment jersey count
            } elseif ($product['category'] == 'scarf') {
                // Use image 2 for scarf
                $product_image = 'img/2_P_Logo.png' . $cache_buster;
            } elseif ($product['category'] == 'cap') {
                // Use image 4 for cap
                $product_image = 'img/4_P_Logo.png' . $cache_buster;
            } elseif ($product['category'] == 'jacket') {
                // Use image 1 for jacket
                $product_image = 'img/1_P_Logo.png' . $cache_buster;
            } else {
                // For other products, assign unique images based on product ID
                // Use images 3, 5 for other products (1 is now for jacket)
                $other_images = [3, 5];
                $img_num = $other_images[($product['id'] - 1) % count($other_images)];
                $product_image = 'img/' . $img_num . '_P_Logo.png' . $cache_buster;
            }
            
            $product_idx++;
            
            echo '<div class="product-card">
                        <a href="index.php?action=product&id=' . $product['id'] . '" class="product-link">
                        <div class="product-image">
                                <img src="' . $product_image . '" alt="' . htmlspecialchars($product['name']) . '" class="img-fluid">
                        </div>
                        <div class="product-info">
                            <h5>' . htmlspecialchars($product['name']) . '</h5>
                                <p class="text-muted small">' . htmlspecialchars($short_desc) . '</p>
                            <p class="product-price">$' . number_format($product['price'], 2) . '</p>
                        </div>
                        </a>
                        <button onclick="event.stopPropagation(); addToCart(\'product\', ' . $product['id'] . ', null, 1)" class="btn btn-red w-100">
                                <i class="fas fa-cart-plus"></i> زیدەکرن بو سەلکێ
                            </button>
                  </div>';
            $product_idx++;
        }
        
        echo '</div>
                        </div>
                        <button class="carousel-btn carousel-btn-right" onclick="scrollProducts(1)">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
            </section>

            <script>
            let currentProductIndex = 0;
            const totalProducts = ' . count($all_products) . ';
            
            function scrollProducts(direction) {
                const carousel = document.getElementById(\'productsCarousel\');
                const container = carousel.querySelector(\'.products-container\');
                const productCards = container.querySelectorAll(\'.product-card\');
                
                if (productCards.length === 0) return;
                
                currentProductIndex += direction;
                
                // Loop around
                if (currentProductIndex < 0) {
                    currentProductIndex = productCards.length - 1;
                } else if (currentProductIndex >= productCards.length) {
                    currentProductIndex = 0;
                }
                
                // Calculate scroll position
                const cardWidth = productCards[0].offsetWidth;
                const gap = 20;
                const scrollPosition = currentProductIndex * (cardWidth + gap);
                
                carousel.scrollTo({
                    left: scrollPosition,
                    behavior: \'smooth\'
                });
            }
            </script>';
            } // End hide shop section for admin
            
            echo '<!-- Footer -->
            <footer class="bg-dark text-white py-5">
                <div class="container">
                    <div class="row align-items-center">
                        <!-- Logo and Basic Info -->
                        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
                            <div class="footer-brand d-flex align-items-center mb-3">
                                <img src="img/ZFC_Logo.png" alt="Zakho FC" class="footer-logo me-2" style="height: 75px;">
                                <div>
                                    <h5 class="mb-1">Zakho Football Club</h5>
                                    <p class="mb-0 text-muted small">Est. 1987</p>
                                </div>
                            </div>
                            <p class="text-muted mb-0">
                                Passion • Tradition • Excellence<br>
                                Zakho International Stadium, Kurdistan Region, Iraq
                            </p>
                        </div>
                        
                        <!-- Support -->
                        <div class="col-lg-2 col-md-3 col-6 mb-4 mb-md-0">
                            <h6 class="text-uppercase fw-bold mb-3">Support</h6>
                            <ul class="list-unstyled">
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Contact Us</a></li>
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">FAQ</a></li>
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Shipping</a></li>
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Returns</a></li>
                            </ul>
                        </div>
                        
                        <!-- Social & Contact -->
                        <div class="col-lg-4 col-md-12">
                            <h6 class="text-uppercase fw-bold mb-3">Connect With Us</h6>
                            <div class="social-links mb-3">
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-instagram"></i>
                                </a>
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-youtube"></i>
                                </a>
                                <a href="#" class="text-white social-icon">
                                    <i class="fab fa-tiktok"></i>
                                </a>
                            </div>
                            <div class="contact-info">
                                <p class="mb-1 text-muted small">
                                    <i class="fas fa-envelope me-2"></i>info@zakhofc.com
                                </p>
                                <p class="mb-0 text-muted small">
                                    <i class="fas fa-phone me-2"></i>+964 750 123 4567
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <hr class="my-4 bg-secondary">
                    
                    <!-- Copyright -->
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center text-md-start">
                            <p class="mb-0 text-muted">
                                &copy; ٢٠٢٥ ياريگه هـا زاخۆ. هەموو مافەکان پارێزراون.
                            </p>
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-links">
                                <a href="#" class="text-muted text-decoration-none me-3 small">Privacy Policy</a>
                                <a href="#" class="text-muted text-decoration-none me-3 small">Terms of Service</a>
                                <a href="#" class="text-muted text-decoration-none small">Cookie Policy</a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

            <!-- JavaScript -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script>
                // Set login status for JavaScript
                const isUserLoggedIn = ' . (isset($user) ? 'true' : 'false') . ';
            </script>
            <script src="js/cart.js"></script>
        </body>
        </html>';
    }
    
    public function showLoginForm($error = '') {
        echo '<!DOCTYPE html>
        <html lang="ku" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>چوونەژوورەوە - ياريگه هـا زاخۆ</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
        </head>
        <body class="auth-body">
            <div class="auth-container">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 40px; margin-right: 10px;">
                        <div class="club-logo auth-logo">
                            <span class="logo-text">ZAKHO</span>
                            <small>FC</small>
                        </div>
                        <h2>چووناژوور</h2>
                    </div>
                    
                    ' . ($error ? '<div class="alert alert-danger">' . $error . '</div>' : '') . '
                    
                    <form method="POST" action="index.php?action=signin">
                        <div class="mb-3">
                            <label class="form-label">ناونیشانی ئیمەیڵ</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ژمارا نهێنی</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-red w-100">چووناژوور</button>
                    </form>
                    
                    <div class="text-center mt-3">
                        <a href="index.php?action=signup" class="text-red">هەژمار نیە؟ خۆتۆمارکه</a>
                    </div>
                </div>
            </div>
        </body>
        </html>';
    }
    
    public function showSignupForm($error = '') {
        echo '<!DOCTYPE html>
        <html lang="ku" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>خۆتۆمارکردن - ياريگه هـا زاخۆ</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
        </head>
        <body class="auth-body">
            <div class="auth-container">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 40px; margin-right: 10px;">
                        <div class="club-logo auth-logo">
                            <span class="logo-text">ZAKHO</span>
                            <small>FC</small>
                        </div>
                        <h2>دروستکردنا هەژمار</h2>
                    </div>
                    
                    ' . ($error ? '<div class="alert alert-danger">' . $error . '</div>' : '') . '
                    
                    <form method="POST" action="index.php?action=signup">
                        <div class="mb-3">
                            <label class="form-label"> ناڤێ سیانی</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ناڤێ بەکارهێنەر</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ناونیشانی ئیمەیڵ</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ژمارا نهێنی</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-red w-100">دروستکردنا هەژمار</button>
                    </form>
                    
                    <div class="text-center mt-3">
                        <a href="index.php?action=signin" class="text-red">پێشتر هەژمار هەیە؟ چووناژوور</a>
                    </div>
                </div>
            </div>
        </body>
        </html>';
    }
    
    public function showCart($cart_items) {
        echo '<!DOCTYPE html>
        <html lang="ku" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title> سەلک-  ياريگه هـا زاخۆ</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
        </head>
        <body>
            <!-- Navigation -->
            <nav class="navbar navbar-expand-lg navbar-dark bg-red" style="direction: rtl;">
                <div class="container" style="flex-direction: row-reverse;">
                    <a class="navbar-brand" href="index.php">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 40px; margin-right: 10px;">
                        <div class="club-logo">
                            <span class="logo-text">ZAKHO</span>
                            <small>FC</small>
                        </div>
                    </a>
                    <div class="navbar-nav ms-auto" style="direction: rtl; flex-direction: row-reverse;">
                        <a class="nav-link" href="index.php?action=cart"><i class="fas fa-shopping-cart"></i> سەبەتە</a>
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> سەرەکی</a>
                    </div>
                </div>
            </nav>

            <div class="container my-5">
                <h1 class="text-center mb-5">سەلک</h1>';
        
        if (empty($cart_items)) {
            echo '<div class="text-center py-5">
                    <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                    <h3>سەلک بەتاڵە</h3>
                    <p>دەست ب کرینێ بکە</p>
                    <a href="index.php" class="btn btn-red">بەردەوامبوون ل فروشگەها تیمێ</a>
                  </div>';
        } else {
            $total = 0;
            echo '<div class="row">
                    <div class="col-md-8">
                        <div class="cart-items">';
            
            echo '<form id="cart-selection-form" onsubmit="return proceedToCheckout(event)">
                    <div class="mb-3">
                        <button type="button" class="btn btn-sm btn-outline-primary" onclick="selectAllItems()">هەموو هەڵبژێرە</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="deselectAllItems()">هەموو لابەرە</button>
                    </div>';
            
            foreach($cart_items as $item) {
                $price = $item['item_type'] == 'product' ? $item['product_price'] : $item['ticket_price'];
                $item_total = $price * $item['quantity'];
                $total += $item_total;
                
                echo '<div class="cart-item card mb-3" id="cart-item-' . $item['id'] . '">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-md-1">
                                    <input type="checkbox" class="form-check-input cart-item-checkbox" name="selected_items[]" value="' . $item['id'] . '" checked onchange="updateSelectedTotal()" style="width: 20px; height: 20px; cursor: pointer;">
                                </div>
                                <div class="col-md-5">
                                    <h5>' . ($item['item_type'] == 'product' ? htmlspecialchars($item['product_name']) : 'بلیت: ' . htmlspecialchars($item['home_team']) . ' بەرامبەر ' . htmlspecialchars($item['away_team'])) . '</h5>
                                    <p class="text-muted mb-0">' . ($item['item_type'] == 'product' ? 'جل و بەرگ' : 'بلیتا یاری') . '</p>
                                </div>
                                <div class="col-md-2">
                                    <p class="mb-0"><strong>$' . number_format($price, 2) . '</strong></p>
                                </div>
                                <div class="col-md-2">
                                    <div class="quantity-controls">
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="updateQuantity(' . $item['id'] . ', ' . ($item['quantity'] - 1) . ')">-</button>
                                        <span class="mx-2">' . $item['quantity'] . '</span>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="updateQuantity(' . $item['id'] . ', ' . ($item['quantity'] + 1) . ')">+</button>
                                    </div>
                                </div>
                                <div class="col-md-2 text-end">
                                    <p class="mb-2 item-total" data-item-id="' . $item['id'] . '" data-price="' . $price . '" data-quantity="' . $item['quantity'] . '"><strong>$' . number_format($item_total, 2) . '</strong></p>
                                    <button type="button" class="btn btn-sm btn-danger" onclick="removeFromCart(' . $item['id'] . ')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                      </div>';
            }
            
            echo '</form>';
            
            echo '</div>
                  </div>
                  <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">پوختەی داواکاری</h5>
                            <div class="d-flex justify-content-between mb-2">
                                <span>کۆی ناوەڕاست:</span>
                                <span>$' . number_format($total, 2) . '</span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>گەیاندن:</span>
                                <span>بەخۆڕایی</span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between mb-3">
                                <strong>کومکرنا گشتی:</strong>
                                <strong id="selected-total">$' . number_format($total, 2) . '</strong>
                            </div>
                            <button type="button" class="btn btn-red w-100" onclick="proceedToCheckout()" id="checkout-btn">
                                <i class="fas fa-shopping-bag"></i> بەردەوامبوون بۆ چێکئاوت
                            </button>
                            <div class="mt-2 text-center">
                                <small class="text-muted" id="selection-message">هەموو بەرهەمەکان هەڵبژێردراون</small>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>';
        }
        
        echo '</div>
            <script src="js/cart.js"></script>
            <script>
            function selectAllItems() {
                document.querySelectorAll(".cart-item-checkbox").forEach(cb => cb.checked = true);
                updateSelectedTotal();
            }
            
            function deselectAllItems() {
                document.querySelectorAll(".cart-item-checkbox").forEach(cb => cb.checked = false);
                updateSelectedTotal();
            }
            
            function updateSelectedTotal() {
                let total = 0;
                let selectedCount = 0;
                const checkboxes = document.querySelectorAll(".cart-item-checkbox:checked");
                
                checkboxes.forEach(checkbox => {
                    const itemId = checkbox.value;
                    const itemElement = document.querySelector(`.item-total[data-item-id="${itemId}"]`);
                    if (itemElement) {
                        const price = parseFloat(itemElement.getAttribute("data-price"));
                        const quantity = parseInt(itemElement.getAttribute("data-quantity"));
                        total += price * quantity;
                        selectedCount++;
                    }
                });
                
                document.getElementById("selected-total").textContent = "$" + total.toFixed(2);
                
                const messageEl = document.getElementById("selection-message");
                const checkoutBtn = document.getElementById("checkout-btn");
                
                if (selectedCount === 0) {
                    messageEl.textContent = "تکایە لانیکەم یەک بەرهەم هەڵبژێرە";
                    messageEl.className = "text-danger";
                    checkoutBtn.disabled = true;
                } else {
                    const totalItems = document.querySelectorAll(".cart-item-checkbox").length;
                    if (selectedCount === totalItems) {
                        messageEl.textContent = "هەموو بەرهەمەکان هەڵبژێردراون";
                    } else {
                        messageEl.textContent = selectedCount + " بەرهەم هەڵبژێردراون";
                    }
                    messageEl.className = "text-muted";
                    checkoutBtn.disabled = false;
                }
            }
            
            function proceedToCheckout(event) {
                if (event) {
                    event.preventDefault();
                }
                
                const selectedItems = Array.from(document.querySelectorAll(".cart-item-checkbox:checked"))
                    .map(cb => cb.value);
                
                if (selectedItems.length === 0) {
                    alert("تکایە لانیکەم یەک بەرهەم هەڵبژێرە بۆ چێکئاوت");
                    return false;
                }
                
                // Store selected items in sessionStorage and redirect
                sessionStorage.setItem("selectedCartItems", JSON.stringify(selectedItems));
                window.location.href = "index.php?action=checkout&items=" + selectedItems.join(",");
                return false;
            }
            
            // Initialize on page load
            document.addEventListener("DOMContentLoaded", function() {
                updateSelectedTotal();
            });
            </script>
        </body>
        </html>';
    }
    
    public function showCheckout($cart_items) {
        $total = 0;
        foreach($cart_items as $item) {
            $price = $item['item_type'] == 'product' ? $item['product_price'] : $item['ticket_price'];
            $total += $price * $item['quantity'];
        }
        
        echo '<!DOCTYPE html>
        <html lang="ku" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>چێکئاوت - ياريگه ها زاخۆ</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
        </head>
        <body>
            <!-- Navigation -->
            <nav class="navbar navbar-expand-lg navbar-dark bg-red" style="direction: rtl;">
                <div class="container" style="flex-direction: row-reverse;">
                    <a class="navbar-brand" href="index.php">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 40px; margin-right: 10px;">
                        <div class="club-logo">
                            <span class="logo-text">ZAKHO</span>
                            <small>FC</small>
                        </div>
                    </a>
                </div>
            </nav>

            <div class="container my-5">
                <h1 class="text-center mb-5">چێکئاوت</h1>
                
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">زانیارگەیاندنی </h5>
                                <form id="checkout-form">';
        
        // Add hidden field for selected items
        if (isset($_GET['items']) && !empty($_GET['items'])) {
            $selected_ids = explode(',', $_GET['items']);
            foreach ($selected_ids as $id) {
                echo '<input type="hidden" name="selected_items[]" value="' . htmlspecialchars($id) . '">';
            }
        }
        
        echo '                                    <div class="mb-3">
                                        <label class="form-label">ناوی تەواو</label>
                                        <input type="text" class="form-control" value="' . htmlspecialchars($_SESSION['user']['name']) . '" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">ژمارەی تەلەفۆن *</label>
                                        <input type="tel" class="form-control" name="phone" placeholder="ژمارەی تەلەفۆنەکەت بنووسە" required>
                                        <div class="form-text">بۆ دڵنیاکردنەوەی داواکاری پەیوەندیت پێوە دەکەین</div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"> ناڤ و نیشانێت گەهاندنێ *</label>
                                        <textarea class="form-control" name="shipping_address" rows="4" placeholder="ناونیشانی تەواوی گەیاندن بنووسە..." required></textarea>
                                        <div class="form-text">   دەمێ ئوردەرا تە دگەهیت پارا بدە  </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"> شێوازێ پارەدانێ *</label>
                                        <select class="form-select" name="payment_method" id="payment_method" required>
                                            <option value="cash">پارەدان لە کاتی وەرگرتندا</option>
                                            <option value="card">کارتا بانکی</option>
                                            <option value="mobile_payment">پارەدانا مۆبایل (زەین کاش، هتد)</option>
                                        </select>
                                        <div class="form-text" id="payment_info">دەمێ ئوردەرا تە دگەهیت پارا بدە</div>
                                    </div>
                                    
                                    <div class="mb-3" id="card_details" style="display: none;">
                                        <label class="form-label">ژمارا کارت</label>
                                        <input type="text" class="form-control" name="card_number" placeholder="1234 5678 9012 3456" maxlength="19">
                                        <div class="row mt-2">
                                            <div class="col-md-6">
                                                <label class="form-label">بەروارا کۆتایی</label>
                                                <input type="text" class="form-control" name="card_expiry" placeholder="MM/YY" maxlength="5">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">CVV</label>
                                                <input type="text" class="form-control" name="card_cvv" placeholder="123" maxlength="4">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3" id="mobile_payment_info" style="display: none;">
                                        <label class="form-label">ژمارا پارەدانا مۆبایل</label>
                                        <input type="text" class="form-control" name="mobile_payment_number" placeholder="ژمارەی پارەدانا مۆبایل بنووسە">
                                        <div class="form-text">ڕێنمایا پارەدان بە SMS دەنێرین</div>
                                    </div>
                                    
                                    <script>
                                    document.getElementById(\'payment_method\').addEventListener(\'change\', function() {
                                        const method = this.value;
                                        const cardDetails = document.getElementById(\'card_details\');
                                        const mobileInfo = document.getElementById(\'mobile_payment_info\');
                                        const paymentInfo = document.getElementById(\'payment_info\');
                                        
                                        // Hide all first
                                        cardDetails.style.display = \'none\';
                                        mobileInfo.style.display = \'none\';
                                        
                                        // Show relevant section
                                        if (method === \'card\') {
                                            cardDetails.style.display = \'block\';
                                            paymentInfo.textContent = \'زانیاریا کارتاخو  بنووسە\';
                                        } else if (method === \'mobile_payment\') {
                                            mobileInfo.style.display = \'block\';
                                            paymentInfo.textContent = \'ڕێنمایی پارەدان بۆ تەلەفۆنەکەت دەنێردرێت\';
                                        } else {
                                            paymentInfo.textContent = \'دەمێ ئوردەرا تە دگەهیت پارا بدە\';
                                        }
                                    });
                                    </script>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">پوختەی داواکاری</h5>';
        
        foreach($cart_items as $item) {
            $price = $item['item_type'] == 'product' ? $item['product_price'] : $item['ticket_price'];
            $item_total = $price * $item['quantity'];
            
            echo '<div class="d-flex justify-content-between mb-2">
                    <span>' . $item['quantity'] . 'x ' . ($item['item_type'] == 'product' ? htmlspecialchars($item['product_name']) : 'بلیت: ' . htmlspecialchars($item['home_team']) . ' بەرامبەر ' . htmlspecialchars($item['away_team'])) . '</span>
                    <span>$' . number_format($item_total, 2) . '</span>
                  </div>';
        }
        
        echo '<hr>
                                <div class="d-flex justify-content-between mb-3">
                                    <strong>کۆی گشتی:</strong>
                                    <strong>$' . number_format($total, 2) . '</strong>
                                </div>
                                 <button type="button" class="btn btn-red w-100" id="place-order-btn" onclick="placeOrder()">
                                    <i class="fas fa-shopping-bag"></i> ناردنی داواکاری
                                 </button>
                                 <a href="index.php?action=cart" class="btn btn-outline-secondary w-100 mt-2">گەڕانەوە بۆ سەبەتە</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script src="js/cart.js"></script>
        </body>
        </html>';
    }
    
    public function showOrders($orders) {
        echo '<!DOCTYPE html>
        <html lang="ku" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>داخازیێت من - ياريگه هـا زاخۆ</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
        </head>
        <body>
            <!-- Navigation -->
            <nav class="navbar navbar-expand-lg navbar-dark bg-red" style="direction: rtl;">
                <div class="container" style="flex-direction: row-reverse;">
                    <a class="navbar-brand" href="index.php">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 40px; margin-right: 10px;">
                        <div class="club-logo">
                            <span class="logo-text">ZAKHO</span>
                            <small>FC</small>
                        </div>
                    </a>
                    <div class="navbar-nav ms-auto" style="direction: rtl; flex-direction: row-reverse;">
                        <a class="nav-link" href="index.php?action=orders"><i class="fas fa-receipt"></i> داواکاریەکانم</a>
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> سەرەکی</a>
                    </div>
                </div>
            </nav>

            <div class="container my-5">
                <h1 class="text-center mb-5">My Orders</h1>';
        
        if (empty($orders)) {
            echo '<div class="text-center py-5">
                    <i class="fas fa-receipt fa-3x text-muted mb-3"></i>
                    <h3>No orders yet</h3>
                    <p>Start shopping to see your orders here!</p>
                    <a href="index.php" class="btn btn-red">Start Shopping</a>
                  </div>';
        } else {
            foreach($orders as $order) {
                $status_color = $order['status'] == 'delivered' ? 'success' : 
                              ($order['status'] == 'shipped' ? 'primary' : 
                              ($order['status'] == 'confirmed' ? 'info' : 'warning'));
                
                echo '<div class="card mb-4">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5>داواکاری #' . $order['id'] . '</h5>
                                    <p class="text-muted">نێردراوە لە ' . date('M j, Y g:i A', strtotime($order['created_at'])) . '</p>
                                    <p><strong>کاڵاکان:</strong> ' . htmlspecialchars($order['items']) . '</p>
                                </div>
                                <div class="col-md-3">
                                    <p><strong> کومکرنا گشتی: $' . number_format($order['total_amount'], 2) . '</strong></p>
                                    <p><strong>پارەدان:</strong> ' . $this->translatePaymentMethod($order['payment_method'] ?? 'cash') . '</p>
                                </div>
                                <div class="col-md-3 text-end">
                                    <span class="badge bg-' . $status_color . '">' . $this->translateStatus($order['status']) . '</span>
                                    <p class="mt-2"><strong>جۆر:</strong> ' . $this->translateOrderType($order['order_type']) . '</p>
                                </div>
                            </div>';
                
                if (!empty($order['shipping_address'])) {
                    echo '<div class="mt-3">
                            <strong> ناڤ و نیشانێت گەهاندنێ:</strong>
                            <p class="text-muted">' . nl2br(htmlspecialchars($order['shipping_address'])) . '</p>
                          </div>';
                }
                
                if (!empty($order['phone'])) {
                    echo '<div class="mt-2">
                            <strong>تەلەفۆن:</strong>
                            <p class="text-muted">' . htmlspecialchars($order['phone']) . '</p>
                          </div>';
                }
                
                echo '</div>
                      </div>';
            }
        }
        
        echo '</div>
        </body>
        </html>';
    }
    
    public function showProductDetail($product, $all_products = [], $user = null) {
        // Find current product index for navigation
        $current_index = 0;
        foreach ($all_products as $idx => $p) {
            if ($p['id'] == $product['id']) {
                $current_index = $idx;
                break;
            }
        }
        $prev_product = $current_index > 0 ? $all_products[$current_index - 1] : null;
        $next_product = $current_index < count($all_products) - 1 ? $all_products[$current_index + 1] : null;
        
        // Available sizes (you can customize this based on product category)
        $sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
        if ($product['category'] == 'cap') {
            $sizes = ['One Size'];
        } elseif ($product['category'] == 'scarf') {
            $sizes = ['One Size'];
        }
        
        echo '<!DOCTYPE html>
        <html lang="ku" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>' . htmlspecialchars($product['name']) . ' - Zakho FC</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
<style>
                .product-detail-container {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 40px 20px;
                }
                .product-images {
                display: flex;
                    gap: 10px;
                    margin-bottom: 20px;
                }
                .main-image {
                    flex: 1;
                    border-radius: 10px;
                    overflow: hidden;
                    background: #f8f9fa;
                }
                .main-image img {
                    width: 100%;
                    height: 500px;
                    object-fit: cover;
                }
                .thumbnail-images {
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                }
                .thumbnail {
                    width: 80px;
                    height: 80px;
                    border-radius: 5px;
                    overflow: hidden;
                    cursor: pointer;
                    border: 2px solid transparent;
                    transition: all 0.3s ease;
                }
                .thumbnail:hover, .thumbnail.active {
                    border-color: var(--red-primary);
                }
                .thumbnail img {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                }
                .product-details {
                    padding: 20px;
                }
                .size-selector {
                display: flex;
                    gap: 10px;
                    margin: 20px 0;
                flex-wrap: wrap;
            }
                .size-option {
                    padding: 10px 20px;
                    border: 2px solid #ddd;
                    border-radius: 5px;
                    cursor: pointer;
                transition: all 0.3s ease;
                    background: white;
                }
                .size-option:hover {
                    border-color: var(--red-primary);
                }
                .size-option.selected {
                    background: var(--red-primary);
                    color: white;
                    border-color: var(--red-primary);
                }
                .size-option.disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }
                .quantity-selector {
                    display: flex;
                    align-items: center;
                    gap: 15px;
                    margin: 20px 0;
                }
                .quantity-btn {
                    width: 40px;
                    height: 40px;
                    border: 1px solid #ddd;
                    background: white;
                    border-radius: 5px;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                }
                .quantity-btn:hover {
                    background: #f8f9fa;
                }
                .quantity-input {
                    width: 60px;
                text-align: center;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    padding: 8px;
                }
            </style>
        </head>
        <body>';
        
        // Include navigation
        echo '<nav class="navbar navbar-expand-lg navbar-dark bg-red">
                <div class="container">
                   <a class="navbar-brand" href="index.php">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 40px; margin-right: 10px;">
                        <div class="club-logo">
                            <span class="logo-text">ZAKHO</span>
                            <small>FC</small>
                        </div>
                    </a>
                            
                    <div class="navbar-nav ms-auto" style="direction: rtl; flex-direction: row-reverse;">
                        ';
                        
                        // User account links first (will appear on left in RTL)
                        if ($user) {
                            echo '<a class="nav-link" href="index.php?action=logout">دەرچوون</a>';
                            echo '<a class="nav-link" href="index.php?action=account"><i class="fas fa-user-circle"></i> هەژماری من</a>';
                            echo '<a class="nav-link" href="index.php?action=orders"><i class="fas fa-receipt"></i> داواکارییەکان</a>';
                        } else {
                            echo '<a class="nav-link" href="index.php?action=signup">خۆتۆمارکردن</a>';
                            echo '<a class="nav-link" href="index.php?action=signin">چوونەژوورەوە</a>';
                        }
                        
                        if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin') {
                            echo '<a class="nav-link" href="index.php?action=admin"><i class="fas fa-cog"></i> پانێلی بەڕێوەبردن</a>';
                        }
                        
                        echo '<a class="nav-link" href="index.php?action=cart">
                            <i class="fas fa-shopping-cart"></i> سەبەتە
                            <span id="cart-counter" class="badge bg-light text-red">0</span>
                        </a>
                        <a class="nav-link" href="index.php?action=stadium">
                            <i class="fas fa-stadium"></i> یاریگا
                        </a>
                        <a class="nav-link" href="index.php?action=team"><i class="fas fa-users"></i> تیم</a>
                        <a class="nav-link" href="index.php#shop"><i class="fas fa-shopping-bag"></i> فروشگە</a>
                        <a class="nav-link" href="index.php#matches"><i class="fas fa-calendar-alt"></i> یاری</a>
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> سەرەکی</a>';
                        
        echo '</div>
                </div>
            </nav>
            
            <div class="product-detail-container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="product-images">
                            <div class="main-image">';
        
        // Determine main image based on product category
        $cache_buster = '?v=' . time() . '&id=' . $product['id'];
        $main_image = 'img/3_P_Logo.png' . $cache_buster;
        $thumbnail_images = [];
        
        if ($product['category'] == 'jersey') {
            // For jerseys, use both red and white jersey images
            $main_image = 'img/jersey_red.png' . $cache_buster;
            $thumbnail_images = ['img/jersey_red.png' . $cache_buster, 'img/jersey_white.png' . $cache_buster];
        } elseif ($product['category'] == 'scarf') {
            $main_image = 'img/2_P_Logo.png' . $cache_buster;
            $thumbnail_images = ['img/2_P_Logo.png' . $cache_buster];
        } elseif ($product['category'] == 'cap') {
            $main_image = 'img/4_P_Logo.png' . $cache_buster;
            $thumbnail_images = ['img/4_P_Logo.png' . $cache_buster];
        } elseif ($product['category'] == 'jacket') {
            $main_image = 'img/1_P_Logo.png' . $cache_buster;
            $thumbnail_images = ['img/1_P_Logo.png' . $cache_buster];
        } else {
            // For other products, use available images (3, 5)
            $product_id = $product['id'];
            $image_map = [3, 5];
            $img_num = $image_map[($product_id - 1) % count($image_map)];
            $main_image = 'img/' . $img_num . '_P_Logo.png' . $cache_buster;
            $thumbnail_images = [$main_image];
        }
        
        echo '<img id="mainProductImage" src="' . $main_image . '" alt="' . htmlspecialchars($product['name']) . '">
                            </div>
                            <div class="thumbnail-images">';
        
        // Generate thumbnails based on product type
        foreach ($thumbnail_images as $idx => $thumb_img) {
            $active = $idx == 0 ? 'active' : '';
            echo '<div class="thumbnail ' . $active . '" onclick="changeImage(\'' . $thumb_img . '\')">
                    <img src="' . $thumb_img . '" alt="Product Image ' . ($idx + 1) . '">
                  </div>';
        }
        
        echo '</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="product-details">
                            <h1>' . htmlspecialchars($product['name']) . '</h1>
                            <p class="text-muted">پۆل: ' . $this->translateCategory($product['category']) . '</p>
                            <h2 class="text-red">$' . number_format($product['price'], 2) . '</h2>
                            
                            <div class="product-description mt-4">
                                <h4>وەسف</h4>
                                <p>' . nl2br(htmlspecialchars($product['description'])) . '</p>
                            </div>
                            
                            <div class="size-selector">
                                <label><strong>قەبارە:</strong></label>';
        
        foreach ($sizes as $size) {
            echo '<div class="size-option" onclick="selectSize(this, \'' . $size . '\')">' . $size . '</div>';
        }
        
        echo '</div>
                            
                            <div class="quantity-selector">
                                <label><strong>بڕ:</strong></label>
                                <button class="quantity-btn" onclick="changeQuantity(-1)">-</button>
                                <input type="number" id="productQuantity" class="quantity-input" value="1" min="1" max="' . $product['stock'] . '">
                                <button class="quantity-btn" onclick="changeQuantity(1)">+</button>
                                <span class="text-muted">(' . $product['stock'] . ' بەردەستە)</span>
                            </div>
                            
                            <button class="btn btn-red btn-lg w-100 mt-4" onclick="addProductToCart()">
                                <i class="fas fa-cart-plus"></i>  زیدەکرن بو سەلکێ 
                            </button>
                            
                            <div class="product-navigation mt-5 d-flex justify-content-between">
                                ' . ($prev_product ? '<a href="index.php?action=product&id=' . $prev_product['id'] . '" class="btn btn-outline-secondary"><i class="fas fa-chevron-left"></i> پێشوو</a>' : '<span></span>') . '
                                <a href="index.php#shop" class="btn btn-outline-secondary">گەڕانەوە بۆ فرۆشگا</a>
                                ' . ($next_product ? '<a href="index.php?action=product&id=' . $next_product['id'] . '" class="btn btn-outline-secondary">دواتر <i class="fas fa-chevron-right"></i></a>' : '<span></span>') . '
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <script>
            let selectedSize = null;
            let productId = ' . $product['id'] . ';
            let maxStock = ' . $product['stock'] . ';
            
            function changeImage(imageSrc) {
                document.getElementById(\'mainProductImage\').src = imageSrc;
                document.querySelectorAll(\'.thumbnail\').forEach(thumb => thumb.classList.remove(\'active\'));
                event.target.closest(\'.thumbnail\').classList.add(\'active\');
            }
            
            function selectSize(element, size) {
                document.querySelectorAll(\'.size-option\').forEach(opt => opt.classList.remove(\'selected\'));
                element.classList.add(\'selected\');
                selectedSize = size;
            }
            
            function changeQuantity(delta) {
                const input = document.getElementById(\'productQuantity\');
                let value = parseInt(input.value) + delta;
                if (value < 1) value = 1;
                if (value > maxStock) value = maxStock;
                input.value = value;
            }
            
            function addProductToCart() {
                if (!selectedSize && ' . (in_array($product['category'], ['jersey', 'jacket', 'other']) ? 'true' : 'false') . ') {
                    alert(\'تکایە قەبارە هەڵبژێرە\');
                    return;
                }
                const quantity = parseInt(document.getElementById(\'productQuantity\').value);
                addToCart(\'product\', productId, null, quantity);
            }
            </script>
            
            <script src="js/cart.js"></script>
        </body>
        </html>';
    }
    
    public function showAccountManagement($user) {
        echo '<!DOCTYPE html>
        <html lang="ku" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>هەژمارا من - ياريگه ها زاخۆ</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
            <style>
                .account-container {
                    max-width: 800px;
                    margin: 40px auto;
                    padding: 0 20px;
                }
                .account-card {
                background: white;
                    border-radius: 10px;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
                    padding: 30px;
                    margin-bottom: 20px;
                }
                .account-card h2 {
                    color: var(--red-primary);
                    margin-bottom: 25px;
                    border-bottom: 2px solid #eee;
                    padding-bottom: 15px;
                }
                .form-group {
                    margin-bottom: 20px;
                }
                .form-group label {
                    font-weight: 600;
                color: #333;
                    margin-bottom: 8px;
                    display: block;
                }
                .form-group input {
                    width: 100%;
                    padding: 12px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    font-size: 16px;
                }
                .form-group input:focus {
                    outline: none;
                    border-color: var(--red-primary);
                    box-shadow: 0 0 0 3px rgba(220, 53, 69, 0.1);
                }
                .btn-account {
                    padding: 12px 30px;
                    border-radius: 5px;
                    font-weight: 600;
                    margin-right: 10px;
                }
                .danger-zone {
                    border-top: 2px solid #dc3545;
                    margin-top: 30px;
                    padding-top: 20px;
                }
                .danger-zone h3 {
                    color: #dc3545;
                    margin-bottom: 15px;
                }
                .alert {
                    padding: 15px;
                    border-radius: 5px;
                    margin-bottom: 20px;
                    display: none;
                }
                .alert-success {
                    background: #d4edda;
                    color: #155724;
                    border: 1px solid #c3e6cb;
                }
                .alert-danger {
                    background: #f8d7da;
                    color: #721c24;
                    border: 1px solid #f5c6cb;
                }
            </style>
        </head>
        <body>';
        
        // Include navigation
        echo '<nav class="navbar navbar-expand-lg navbar-dark bg-red">
                <div class="container">
                   <a class="navbar-brand" href="index.php">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 40px; margin-right: 10px;">
                        <div class="club-logo">
                            <span class="logo-text">ZAKHO</span>
                            <small>FC</small>
                        </div>
                    </a>
                            
                    <div class="navbar-nav ms-auto" style="direction: rtl; flex-direction: row-reverse;">
                        ';
                        
                        // User account links first (will appear on left in RTL)
                        echo '<a class="nav-link" href="index.php?action=logout">دەرچوون</a>';
                        echo '<a class="nav-link" href="index.php?action=account"><i class="fas fa-user-circle"></i> هەژماری من</a>';
                        echo '<a class="nav-link" href="index.php?action=orders"><i class="fas fa-receipt"></i> داواکاریەکان</a>';
                        
                        if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin') {
                            echo '<a class="nav-link" href="index.php?action=admin"><i class="fas fa-cog"></i> پانێلی بەڕێوەبردن</a>';
                        }
                        
                        echo '<a class="nav-link" href="index.php?action=cart">
                            <i class="fas fa-shopping-cart"></i> سەبەتە
                            <span id="cart-counter" class="badge bg-light text-red">0</span>
                        </a>
                        <a class="nav-link" href="index.php?action=stadium">
                            <i class="fas fa-stadium"></i> یاریگا
                        </a>
                        <a class="nav-link" href="index.php?action=team"><i class="fas fa-users"></i> تیم</a>
                        <a class="nav-link" href="#shop"><i class="fas fa-shopping-bag"></i> فروشگە</a>
                        <a class="nav-link" href="#matches"><i class="fas fa-calendar-alt"></i> یاری</a>
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> سەرەکی</a>';
                        
        echo '</div>
                </div>
            </nav>
            
            <div class="account-container">
                <div class="account-card">
                    <h2><i class="fas fa-user"></i> زانیاری هەژمار</h2>
                    
                    <div id="alertMessage" class="alert"></div>
                    
                    <form id="editAccountForm">
                        <div class="form-group">
                            <label for="name"> ناڤێ سیانی</label>
                            <input type="text" id="name" name="name" value="' . htmlspecialchars($user['name']) . '" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="username">ناڤي  بەکارهێنەر</label>
                            <input type="text" id="username" name="username" value="' . htmlspecialchars($user['username']) . '" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">ئیمەیڵ</label>
                            <input type="email" id="email" name="email" value="' . htmlspecialchars($user['email']) . '" required>
                        </div>
                        
                        <div class="form-group">
                            <label>گۆڕینی تێپەڕەوشە (بە بەتاڵی بەجێبهێڵە بۆ پاراستنی تێپەڕەوشەی ئێستا)</label>
                            <input type="password" id="current_password" name="current_password" placeholder="  ژمارا نهێنی يا نوكه ">
                            <small class="text-muted d-block mt-2">تەنها ئەگەر تێپەڕەوشەت بگۆڕیت پێویستە</small>
                        </div>
                        
                        <div class="form-group">
                            <input type="password" id="new_password" name="new_password" placeholder="تێپەڕەوشەی نوێ (کەمتر لە ٦ پیت نەبێت)">
                        </div>
                        
                        <button type="submit" class="btn btn-red btn-account">
                            <i class="fas fa-save"></i> نوێکردنەوەی هەژمار
                        </button>
                        <a href="index.php" class="btn btn-secondary btn-account">
                            <i class="fas fa-arrow-left"></i> گەڕاندن بۆ سەرەکی
                        </a>
                    </form>
                    
                    <div class="danger-zone">
                        <h3><i class="fas fa-exclamation-triangle"></i>  </h3>
                        <p class="text-muted">  دەمێ هەژمارا تە دهێتە ژێبرن ڤەکەراندن نینە، هیڤیدکم پشت راستبە! </p>
                        <button type="button" class="btn btn-danger" onclick="showDeleteConfirm()">
                            <i class="fas fa-trash"></i>  ژێبرنا هەژمارا من
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Delete Account Modal -->
            <div class="modal fade" id="deleteAccountModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-danger text-white">
                            <h5 class="modal-title"><i class="fas fa-exclamation-triangle"></i> Delete Account</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>Are you sure you want to delete your account? This action cannot be undone.</p>
                            <p class="text-danger"><strong>All your data, orders, and cart items will be permanently deleted.</strong></p>
                            <div class="form-group mt-3">
                                <label for="deletePassword">Enter your password to confirm:</label>
                                <input type="password" id="deletePassword" class="form-control" placeholder="Your password">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-danger" onclick="deleteAccount()">Delete Account</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script>
            function showAlert(message, type) {
                const alertDiv = document.getElementById("alertMessage");
                alertDiv.className = "alert alert-" + type;
                alertDiv.textContent = message;
                alertDiv.style.display = "block";
                setTimeout(() => {
                    alertDiv.style.display = "none";
                }, 5000);
            }
            
            document.getElementById("editAccountForm").addEventListener("submit", function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const button = this.querySelector("button[type=\'submit\']");
                const originalText = button.innerHTML;
                
                button.innerHTML = \'<i class="fas fa-spinner fa-spin"></i>نوێکردن.\';
                button.disabled = true;
                
                fetch("index.php?action=edit_account", {
                    method: "POST",
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showAlert(data.message, "success");
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        showAlert(data.message, "danger");
                        button.innerHTML = originalText;
                        button.disabled = false;
                    }
                })
                .catch(error => {
                    showAlert("هەڵە لە نوێکردنەوەی هەژمار: " + error.message, "danger");
                    button.innerHTML = originalText;
                    button.disabled = false;
                });
            });
            
            function showDeleteConfirm() {
                const modal = new bootstrap.Modal(document.getElementById("deleteAccountModal"));
                modal.show();
            }
            
            function deleteAccount() {
                const password = document.getElementById("deletePassword").value;
                
                if (!password) {
                    alert("   هیڤیدکم ژمارا نهێنی بنڤیسە");
                    return;
                }
                
                const formData = new FormData();
                formData.append("password", password);
                
                fetch("index.php?action=delete_account", {
                    method: "POST",
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert("هەژمار بە سەرکەوتوویی سڕایەوە. دەگەڕێیتەوە بۆ پەڕەی سەرەکی.");
                        window.location.href = "index.php";
                    } else {
                        alert("خەلەتی: " + data.message);
                    }
                })
                .catch(error => {
                    alert("خەلەتی لە سڕینەوەی هەژمار: " + error.message);
                });
            }
            </script>
        </body>
        </html>';
    }
    
    public function showStadiumPage() {
        $user = $_SESSION['user'] ?? null;
        
        echo '<!DOCTYPE html>
        <html lang="ku" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>  زانیاری لسەر یاڕیگەها زاخۆ  </title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
        </head>
        <body>
            <!-- Navigation -->
            <nav class="navbar navbar-expand-lg navbar-dark bg-red" style="direction: rtl;">
                <div class="container" style="flex-direction: row-reverse;">
                   <a class="navbar-brand" href="index.php">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 40px; margin-right: 10px;">
                        <div class="club-logo">
                            <span class="logo-text">ZAKHO</span>
                            <small>FC</small>
                        </div>
                    </a>
                            
                    <div class="navbar-nav ms-auto" style="direction: rtl; flex-direction: row-reverse;">
                        ';
                        
                        // User account links first (will appear on left in RTL)
                        if ($user) {
                            echo '<a class="nav-link" href="index.php?action=logout">دەرچوون</a>';
                            echo '<a class="nav-link" href="index.php?action=account"><i class="fas fa-user-circle"></i> هەژماری من</a>';
                            echo '<a class="nav-link" href="index.php?action=orders"><i class="fas fa-receipt"></i> داواکارییەکان</a>';
                        } else {
                            echo '<a class="nav-link" href="index.php?action=signup">خۆتۆمارکردن</a>';
                            echo '<a class="nav-link" href="index.php?action=signin">چوونەژوورەوە</a>';
                        }
                        
                        if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin') {
                            echo '<a class="nav-link" href="index.php?action=admin"><i class="fas fa-cog"></i> پانێلی بەڕێوەبردن</a>';
                        }
                        
                        echo '<a class="nav-link" href="index.php?action=cart">
                            <i class="fas fa-shopping-cart"></i> سەبەتە
                            <span id="cart-counter" class="badge bg-light text-red">0</span>
                        </a>
                        <a class="nav-link active" href="index.php?action=stadium">
                            <i class="fas fa-stadium"></i> یاریگا
                        </a>
                        <a class="nav-link" href="index.php?action=team"><i class="fas fa-users"></i> تیم</a>
                        <a class="nav-link" href="index.php#shop"><i class="fas fa-shopping-bag"></i> فروشگە</a>
                        <a class="nav-link" href="index.php#matches"><i class="fas fa-calendar-alt"></i> یاری</a>
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> سەرەکی</a>';
                        
        echo '</div>
                </div>
            </nav>
            
            <!-- Stadium Information Page -->
            <section class="py-5" style="background: linear-gradient(to bottom, #ffffff, #f8f9fa); min-height: calc(100vh - 200px);">
                <div class="container">
                    <div class="row mb-4">
                        <div class="col-12 text-center">
                            <h1 class="display-4 fw-bold text-red mb-3">
                                <i class="fas fa-stadium me-3"></i> یاریگەها نێڤدەولەتی یا زاخۆ  
                                
                            </h1>
                            <p class="lead text-muted">ناوەندا ياريگه هـا زاخۆ</p>
                        </div>
                    </div>
                    
                    <div class="stadium-content-card">
                        <div class="row">
                            <div class="col-lg-6 mb-4">
                                <h2 class="stadium-section-title">دەربارەی ياريگه هـ</h2>
                                <p class="stadium-description">
                                    یاریگای نێودەوڵەتی زاخۆ یاریگایەکی فرە مەبەستە لە زاخۆ، عێراق، کە وەک یاریگای ناوەندی یادگای زاخۆ خزمەت دەکات. 
                                    ئەم دامەزراوەی پێشکەوتووە لە نێوان ٢٠١٢ بۆ ٢٠١٥ بە تێچووی ٢٠ ملیۆن دۆلار دروست کراوە.
                                </p>
                                
                                <div class="stadium-stats-grid">
                                    <div class="stat-box">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <div>
                                            <strong>شوێن</strong>
                                            <p>زاخۆ، هەرێما کوردستان، عێراق</p>
                                        </div>
                                    </div>
                                    
                                    <div class="stat-box">
                                        <i class="fas fa-users"></i>
                                        <div>
                                            <strong>گونجایی</strong>
                                            <p>٢٠,٠٠٠ کورسی</p>
                                        </div>
                                    </div>
                                    
                                    <div class="stat-box">
                                        <i class="fas fa-calendar-alt"></i>
                                        <div>
                                            <strong>دروستکردن</strong>
                                            <p>٢٠١٢ - ٢٠١٥</p>
                                        </div>
                                    </div>
                                    
                                    <div class="stat-box">
                                        <i class="fas fa-dollar-sign"></i>
                                        <div>
                                            <strong>تێچوو</strong>
                                            <p>٢٠ ملیۆن دۆلار</p>
                                        </div>
                                    </div>
                                    
                                    <div class="stat-box">
                                        <i class="fas fa-star"></i>
                                        <div>
                                            <strong>کردنەوە</strong>
                                            <p>٣ی حوزەیرانی ٢٠١٥</p>
                                        </div>
                                    </div>
                                    
                                    <div class="stat-box">
                                        <i class="fas fa-futbol"></i>
                                        <div>
                                            <strong>قەبارەی یاریگا</strong>
                                            <p>١٠٥م x ٦٨م</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-6">
                                <h2 class="stadium-section-title">تایبەتمەندیە سەرەکییەکان</h2>
                                <div class="features-list">
                                    <div class="feature-box">
                                        <i class="fas fa-check-circle"></i>
                                        <div>
                                            <h5>سەقفی سوور و سپی پۆلیکاربۆنات</h5>
                                            <p>سەقفی ١٢,٠٠٠ مەتری چوارگۆشە بە پانێڵی سوور و سپی</p>
                                        </div>
                                    </div>
                                    
                                    <div class="feature-box">
                                        <i class="fas fa-check-circle"></i>
                                        <div>
                                            <h5>هەڵبژاردنی کورسی پێشکەوتوو</h5>
                                            <p>کورسی ستاندارد و VIP بەردەستە</p>
                                        </div>
                                    </div>
                                    
                                    <div class="feature-box">
                                        <i class="fas fa-check-circle"></i>
                                        <div>
                                            <h5>چەندین دەرگای چوونەژوور</h5>
                                            <p>١٢ دەرگای چوونەژوور و دەرچوون</p>
                                        </div>
                                    </div>
                                    
                                    <div class="feature-box">
                                        <i class="fas fa-check-circle"></i>
                                        <div>
                                            <h5>یاریگای ستانداردی FIFA</h5>
                                            <p>یاریگای گژوگیای پیشەیی (١٠٥م x ٦٨م)</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="stadium-opening-info mt-4">
                                    <h5 class="mb-3"><i class="fas fa-info-circle text-red me-2"></i>یاریی کردنەوە</h5>
                                    <p class="mb-0">
                                        یاریگاکە بە فەرمی لە ٣ی حوزەیرانی ٢٠١٥ کرایەوە، بە یارییەک لە نێوان یادگای زاخۆ و تیمی نیشتیمانی عێراق. 
                                        ئەم ڕووداوە مێژووییە دەستپێکردنی سەردەمێکی نوێی تۆپی پێ لە هەرێمی کوردستان بوو.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Stadium Gallery -->
                    <div class="row mt-5">
                        <div class="col-12">
                            <h2 class="stadium-section-title text-center mb-4">گالەری یاریگا</h2>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="stadium-gallery-item">
                                <img src="img/s1.png" alt="دیمەنی دەرەوەی یاریگای نێودەوڵەتی زاخۆ" class="img-fluid rounded shadow-lg mb-3" style="width: 100%; height: auto; max-height: 500px; object-fit: cover;">
                                <div class="stadium-image-info">
                                    <h5 class="text-red mb-2"><i class="fas fa-camera me-2"></i>دیمەنی دەرەوەی یاریگا</h5>
                                    <p class="text-muted">
                                        دیمەنێکی سەرنجڕاکێشی یاریگای نێودەوڵەتی زاخۆ کە دیزاینی سەقفی سەرنجڕاکێشی سوور و سپی پۆلیکاربۆناتەکە پیشان دەدات. 
                                        تەلارسازی مۆدێرن پابەندی کلووبەکە بە نایابی و داهێنان پیشان دەدات.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="stadium-gallery-item">
                                <img src="img/s2.png" alt="دیمەنی ناوەوەی یاریگای نێودەوڵەتی زاخۆ" class="img-fluid rounded shadow-lg mb-3" style="width: 100%; height: auto; max-height: 500px; object-fit: cover;">
                                <div class="stadium-image-info">
                                    <h5 class="text-red mb-2"><i class="fas fa-camera me-2"></i>دیمەنی ناوەوەی یاریگا</h5>
                                    <p class="text-muted">
                                        ناوەوەی یاریگای نێودەوڵەتی زاخۆ کە یاریگای پیشەیی و ڕێکخستنی کورسی پیشان دەدات. 
                                        ئەم دیمەنە گونجایی یاریگاکە و دامەزراوە جیهانییەکان پیشان دەدات کە بۆ پێشکەشکردنی ئەزموونێکی تایبەت بۆ هەواداران و یاریزانان دیزاین کراون.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-5">
                        <a href="index.php" class="btn btn-red btn-lg">
                            <i class="fas fa-arrow-left me-2"></i>گەڕانەوە بۆ سەرەکی
                        </a>
                    </div>
                </div>
            </section>
            
            <!-- Footer -->
            <footer class="bg-dark text-white py-5">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
                            <div class="footer-brand d-flex align-items-center mb-3">
                                <img src="img/ZFC_Logo.png" alt="Zakho FC" class="footer-logo me-2" style="height: 75px;">
                                <div>
                                    <h5 class="mb-1">Zakho Football Club</h5>
                                    <p class="mb-0 text-muted small">Est. 1987</p>
                                </div>
                            </div>
                            <p class="text-muted mb-0">
                                Passion • Tradition • Excellence<br>
                                Zakho International Stadium, Kurdistan Region, Iraq
                            </p>
                        </div>
                        
                        <div class="col-lg-2 col-md-3 col-6 mb-4 mb-md-0">
                            <h6 class="text-uppercase fw-bold mb-3">Support</h6>
                            <ul class="list-unstyled">
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Contact Us</a></li>
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">FAQ</a></li>
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Shipping</a></li>
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Returns</a></li>
                            </ul>
                        </div>
                        
                        <div class="col-lg-4 col-md-12">
                            <h6 class="text-uppercase fw-bold mb-3">Connect With Us</h6>
                            <div class="social-links mb-3">
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-instagram"></i>
                                </a>
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-youtube"></i>
                                </a>
                                <a href="#" class="text-white social-icon">
                                    <i class="fab fa-tiktok"></i>
                                </a>
                            </div>
                            <div class="contact-info">
                                <p class="mb-1 text-muted small">
                                    <i class="fas fa-envelope me-2"></i>info@zakhofc.com
                                </p>
                                <p class="mb-0 text-muted small">
                                    <i class="fas fa-phone me-2"></i>+964 750 123 4567
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <hr class="my-4 bg-secondary">
                    
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center text-md-start">
                            <p class="mb-0 text-muted">
                                &copy; ٢٠٢٥ یادگای زاخۆ. هەموو مافەکان پارێزراون.
                            </p>
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-links">
                                <a href="#" class="text-muted text-decoration-none me-3 small">Privacy Policy</a>
                                <a href="#" class="text-muted text-decoration-none me-3 small">Terms of Service</a>
                                <a href="#" class="text-muted text-decoration-none small">Cookie Policy</a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script>
                // Set login status for JavaScript
                const isUserLoggedIn = ' . (isset($user) ? 'true' : 'false') . ';
            </script>
            <script src="js/cart.js"></script>
        </body>
        </html>';
    }
    
    public function showTeamPage() {
        $user = $_SESSION['user'] ?? null;
        
        // Get team info and players from database
        require_once __DIR__ . '/../models/ClubModel.php';
        $model = new ClubModel();
        $team_info_db = $model->getTeamInfo();
        $players_db = $model->getAllPlayers();
        
        // Use database data if available, otherwise use defaults
        $team_info = !empty($team_info_db) ? $team_info_db : [
            'name' => 'Zakho Sport Club',
            'name_arabic' => 'نادي زاخو الرياضي',
            'founded' => '1987',
            'city' => 'Zakho, Duhok Governorate, Kurdistan Region of Iraq',
            'stadium' => 'Zakho International Stadium',
            'stadium_opened' => '2021',
            'capacity' => '~20,000',
            'league' => 'Iraq Stars League (Iraqi Premier League)',
            'nickname' => 'The Knights of the Frontier',
            'nickname_arabic' => 'فرسان الحدود',
            'colors' => 'Yellow and Black',
            'status' => 'Mid-table team in the Iraqi Premier League. Known for being well-organized and tough opponent, especially at their home fortress. Strong support from local community.',
            'description' => 'دەربارەی یانا وەرزشی زاخۆ

یانا وەرزشی زاخۆ، یانەیەکا تۆپا پێنیا پیشەییە ل زاخۆ، ل هەرێما کوردستانێ، عیراقێ.

ئەڤ یانە ل سالا ١٩٨٧ هاتە دامەزراندن و ل بەرزترین ئاستێن تۆپا پێنیا عیراقێ بەشداریێ دکەت.

تیم ب ناڤێ "فرسان الحدود" (سوارچاکێن سنۆران) دهێتە ناسین، و ب ڕەنگێن سور و سبي یاریێ دکەت.

یانا زاخۆ خودان مێژوویەکا دەولەمەند و هەوادارێن گەلەک گەرم و شەوقدارە.

ئەڤ یانە ل خولا ئەستێرێن عیراقێ یاریێ دکەت و ل یاریگەها نێڤدەولەتی یا زاخۆ یاریێن خوە دکەت.'
        ];
        
        // Use database players if available, otherwise use defaults
        if (!empty($players_db)) {
            $players = [];
            foreach ($players_db as $p) {
                $players[] = [
                    'name' => $p['name'],
                    'position' => $p['position'],
                    'number' => $p['number'],
                    'nationality' => $p['nationality'],
                    'role' => $p['role'],
                    'special' => (bool)($p['is_special'] ?? 0)
                ];
            }
        } else {
            // Default players if database is empty
            $players = [
            // Goalkeepers
            [
                'name' => 'Mohanad Qasim',
                'position' => 'Goalkeeper',
                'number' => '1',
                'nationality' => 'Iraq',
                'role' => 'Reliable goalkeeper'
            ],
            [
                'name' => 'Ali Saeed',
                'position' => 'Goalkeeper',
                'number' => '22',
                'nationality' => 'Iraq',
                'role' => 'Local goalkeeping option'
            ],
            // Defenders
            [
                'name' => 'Hussein Jabbar',
                'position' => 'Defender',
                'number' => '3',
                'nationality' => 'Iraq',
                'role' => 'Experienced defender'
            ],
            [
                'name' => 'Haidar Abdul-Raheem',
                'position' => 'Defender',
                'number' => '4',
                'nationality' => 'Iraq',
                'role' => 'Solid defensive presence'
            ],
            [
                'name' => 'Hussam Malek',
                'position' => 'Defender',
                'number' => '5',
                'nationality' => 'Iraq',
                'role' => 'Tough in the back line'
            ],
            [
                'name' => 'Ali Fayez',
                'position' => 'Defender',
                'number' => '2',
                'nationality' => 'Iraq',
                'role' => 'Full-back'
            ],
            // Midfielders
            [
                'name' => 'Hawar Mulla Mohammed',
                'position' => 'Midfielder',
                'number' => '10',
                'nationality' => 'Iraq',
                'role' => 'Captain & Legend - Kurdish football legend and Iraqi international',
                'special' => true
            ],
            [
                'name' => 'Amjad Attwan',
                'position' => 'Midfielder',
                'number' => '6',
                'nationality' => 'Iraq',
                'role' => 'Iraqi international defensive midfielder - Very significant signing'
            ],
            [
                'name' => 'Mohammed Kalaf',
                'position' => 'Midfielder',
                'number' => '8',
                'nationality' => 'Iraq',
                'role' => 'Young, talented midfielder'
            ],
            [
                'name' => 'Youssef Attal',
                'position' => 'Midfielder',
                'number' => '7',
                'nationality' => 'Iraq',
                'role' => 'Forward/winger in midfield roles'
            ],
            [
                'name' => 'Ali Raheem',
                'position' => 'Midfielder',
                'number' => '14',
                'nationality' => 'Iraq',
                'role' => 'Midfield contributor'
            ],
            // Forwards
            [
                'name' => 'Walid Kamil',
                'position' => 'Forward',
                'number' => '9',
                'nationality' => 'Iraq',
                'role' => 'Pacey forward'
            ],
            [
                'name' => 'Mustafa Saadoun',
                'position' => 'Forward',
                'number' => '11',
                'nationality' => 'Iraq',
                'role' => 'Young Iraqi striker'
            ],
            [
                'name' => 'Karim El Hedoudi',
                'position' => 'Forward',
                'number' => '17',
                'nationality' => 'Algeria',
                'role' => 'Foreign signing'
            ],
            [
                'name' => 'Ahmed Hammad',
                'position' => 'Forward',
                'number' => '19',
                'nationality' => 'Iraq',
                'role' => 'Attacking player'
            ]
            ];
        }
        
        echo '<!DOCTYPE html>
        <html lang="ku" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Team - Zakho FC</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
            <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
            <link rel="stylesheet" href="css/style.css">
            <style>
                .team-hero {
                    background: linear-gradient(135deg, var(--red-primary) 0%, #8b0000 100%);
                    color: white;
                    padding: 60px 0;
                    text-align: center;
                }
                .team-info-card {
                    background: white;
                    border-radius: 15px;
                    padding: 30px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                    margin-bottom: 30px;
                }
                .team-info-item {
                    display: flex;
                    align-items: center;
                    padding: 15px 0;
                    border-bottom: 1px solid #eee;
                }
                .team-info-item:last-child {
                    border-bottom: none;
                }
                .team-info-item i {
                    color: var(--red-primary);
                    font-size: 1.5rem;
                    width: 40px;
                    margin-right: 15px;
                }
                .player-card {
                    background: white;
                    border-radius: 15px;
                    padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: center;
            height: 100%;
        }
        .player-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .player-number {
            background: var(--red-primary);
            color: white;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            font-weight: bold;
            margin: 0 auto 15px;
        }
        .player-name {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 10px;
        }
        .player-position {
            color: var(--red-primary);
            font-weight: 600;
            margin-bottom: 8px;
        }
        .player-details {
            color: #666;
            font-size: 0.9rem;
        }
        .position-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-top: 5px;
        }
        .position-gk { background: #ffc107; color: #000; }
        .position-df { background: #28a745; color: white; }
        .position-mf { background: #007bff; color: white; }
        .position-fw { background: #dc3545; color: white; }
            </style>
        </head>
        <body>
            <!-- Navigation -->
            <nav class="navbar navbar-expand-lg navbar-dark bg-red" style="direction: rtl;">
                <div class="container" style="flex-direction: row-reverse;">
                   <a class="navbar-brand" href="index.php">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 40px; margin-right: 10px;">
                        <div class="club-logo">
                            <span class="logo-text">ZAKHO</span>
                            <small>FC</small>
                        </div>
                    </a>
                            
                    <div class="navbar-nav ms-auto" style="direction: rtl;">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> سەرەکی</a>
                        <a class="nav-link" href="index.php#matches"><i class="fas fa-calendar-alt"></i> یاری</a>
                        <a class="nav-link" href="index.php#shop"><i class="fas fa-shopping-bag"></i> فروشگە</a>
                        <a class="nav-link active" href="index.php?action=team"><i class="fas fa-users"></i> تیم</a>
                        <a class="nav-link" href="index.php?action=stadium"><i class="fas fa-stadium"></i> یاریگا</a>
                        <a class="nav-link" href="index.php?action=cart">
                            <i class="fas fa-shopping-cart"></i> سەبەتە
                            <span id="cart-counter" class="badge bg-light text-red">0</span>
                        </a>';
                        
                        if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin') {
                            echo '<a class="nav-link" href="index.php?action=admin"><i class="fas fa-cog"></i> پانێلی بەڕێوەبردن</a>';
                        }
                        
                        if ($user) {
                            echo '<a class="nav-link" href="index.php?action=orders"><i class="fas fa-receipt"></i> داواکارییەکان</a>';
                            echo '<a class="nav-link" href="index.php?action=account"><i class="fas fa-user-circle"></i> هەژماری من</a>';
                            echo '<a class="nav-link" href="index.php?action=logout">دەرچوون</a>';
                        } else {
                            echo '<a class="nav-link" href="index.php?action=signin">چوونەژوورەوە</a>';
                            echo '<a class="nav-link" href="index.php?action=signup">خۆتۆمارکردن</a>';
                        }
                        
        echo '</div>
                </div>
            </nav>
                
                <!-- Team Hero Section -->
            <section class="team-hero">
                <div class="container">
                    <div class="d-flex align-items-center justify-content-center mb-3 flex-wrap gap-3">
                        <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 120px; filter: drop-shadow(0 4px 8px rgba(0,0,0,0.3));">
                        <div class="text-center text-md-start">
                            <h1 class="display-3 fw-bold mb-2">' . htmlspecialchars($team_info['name']) . '</h1>
                            <p class="h4 mb-2" style="direction: rtl; font-family: Arial, sans-serif;">' . htmlspecialchars($team_info['name_arabic']) . '</p>
                        </div>
                    </div>
                    <p class="lead mb-2">"' . htmlspecialchars($team_info['nickname']) . '" <span style="direction: rtl; font-family: Arial, sans-serif;">(' . htmlspecialchars($team_info['nickname_arabic']) . ')</span></p>
                    <p class="mb-0">هاتە دامەزراندن ل ' . htmlspecialchars($team_info['founded']) . ' • ' . htmlspecialchars($team_info['league']) . '</p>
                </div>
            </section>
            
            <!-- Team Information -->
            <section class="py-5 bg-light">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 mb-4">
                            <div class="team-info-card">
                                <h2 class="text-red mb-4 d-flex align-items-center">
                                    <img src="img/ZFC_Logo.png" alt="Zakho FC" style="height: 50px; margin-left: 10px;">
                                    دەربارەی تیم
                                </h2>
                                <p class="lead">' . htmlspecialchars($team_info['description']) . '</p>
                                <p class="text-muted mt-3">' . htmlspecialchars($team_info['status']) . '</p>
                                
                                <div class="mt-4">
                                    <div class="team-info-item">
                                        <i class="fas fa-calendar-alt"></i>
                                        <div>
                                            <strong>دامەزراندن :</strong> ' . htmlspecialchars($team_info['founded']) . '
                                        </div>
                                    </div>
                                    <div class="team-info-item">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <div>
                                            <strong>شار:</strong> ' . htmlspecialchars($team_info['city']) . '
                                        </div>
                                    </div>
                                    <div class="team-info-item">
                                        <i class="fas fa-stadium"></i>
                                        <div>
                                            <strong>یاریگای ناوەندی:</strong> ' . htmlspecialchars($team_info['stadium']) . ' (کرایەوە لە: ' . htmlspecialchars($team_info['stadium_opened']) . ')
                                        </div>
                                    </div>
                                    <div class="team-info-item">
                                        <i class="fas fa-users"></i>
                                        <div>
                                            <strong>گونجایی یاریگا:</strong> ' . htmlspecialchars($team_info['capacity']) . ' کورسی
                                        </div>
                                    </div>
                                    <div class="team-info-item">
                                        <i class="fas fa-trophy"></i>
                                        <div>
                                            <strong>خول:</strong> ' . htmlspecialchars($team_info['league']) . '
                                        </div>
                                    </div>
                                    <div class="team-info-item">
                                        <i class="fas fa-palette"></i>
                                        <div>
                                            <strong>ڕەنگی تیمێ:</strong> ' . htmlspecialchars($team_info['colors']) . '
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <div class="team-info-card text-center">
                                <h3 class="text-red mb-4"><i class="fas fa-users me-2"></i>هێڵ</h3>
                                <div class="display-1 fw-bold text-red">' . count($players) . '</div>
                                <p class="text-muted mb-0">یاریزان</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <!-- Players Section -->
            <section class="py-5">
                <div class="container">
                    <h2 class="section-title text-center mb-5">یاریزانێت تیمێ</h2>
                    <div class="row">';
        
        foreach ($players as $player) {
            $position_class = '';
            if (stripos($player['position'], 'Goalkeeper') !== false) {
                $position_class = 'position-gk';
            } elseif (stripos($player['position'], 'Defender') !== false) {
                $position_class = 'position-df';
            } elseif (stripos($player['position'], 'Midfielder') !== false) {
                $position_class = 'position-mf';
            } elseif (stripos($player['position'], 'Forward') !== false) {
                $position_class = 'position-fw';
            }
            
            $special_badge = '';
            if (isset($player['special']) && $player['special']) {
                $special_badge = '<span class="badge bg-warning text-dark mb-2"><i class="fas fa-star me-1"></i>ئەفسانە</span>';
            }
            
            echo '<div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                            <div class="player-card" style="' . (isset($player['special']) && $player['special'] ? 'border: 2px solid #ffc107;' : '') . '">
                                <div class="player-number">' . htmlspecialchars($player['number']) . '</div>
                                <div class="player-name">' . htmlspecialchars($player['name']) . '</div>
                                ' . $special_badge . '
                                <div class="player-position">
                                    <span class="position-badge ' . $position_class . '">' . htmlspecialchars($player['position']) . '</span>
                                </div>
                                <div class="player-details mt-3">
                                    <p class="mb-1"><i class="fas fa-flag me-2"></i>' . htmlspecialchars($player['nationality']) . '</p>
                                    <p class="mb-0 text-muted small"><i class="fas fa-info-circle me-2"></i>' . htmlspecialchars($player['role']) . '</p>
                                </div>
                            </div>
                        </div>';
        }
        
        echo '</div>
                </div>
            </section>
            
            <div class="text-center py-4 bg-light">
                <a href="index.php" class="btn btn-red btn-lg">
                    <i class="fas fa-arrow-left me-2"></i>Back to Home
                </a>
            </div>
            
            <!-- Footer -->
            <footer class="bg-dark text-white py-5">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
                            <div class="footer-brand d-flex align-items-center mb-3">
                                <img src="img/ZFC_Logo.png" alt="Zakho FC" class="footer-logo me-2" style="height: 75px;">
                                <div>
                                    <h5 class="mb-1">Zakho Football Club</h5>
                                    <p class="mb-0 text-muted small">Est. 1987</p>
                                </div>
                            </div>
                            <p class="text-muted mb-0">
                                Passion • Tradition • Excellence<br>
                                Zakho International Stadium, Kurdistan Region, Iraq
                            </p>
                        </div>
                        
                        <div class="col-lg-2 col-md-3 col-6 mb-4 mb-md-0">
                            <h6 class="text-uppercase fw-bold mb-3">Support</h6>
                            <ul class="list-unstyled">
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Contact Us</a></li>
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">FAQ</a></li>
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Shipping</a></li>
                                <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Returns</a></li>
                            </ul>
                        </div>
                        
                        <div class="col-lg-4 col-md-12">
                            <h6 class="text-uppercase fw-bold mb-3">Connect With Us</h6>
                            <div class="social-links mb-3">
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-instagram"></i>
                                </a>
                                <a href="#" class="text-white me-3 social-icon">
                                    <i class="fab fa-youtube"></i>
                                </a>
                                <a href="#" class="text-white social-icon">
                                    <i class="fab fa-tiktok"></i>
                                </a>
                            </div>
                            <div class="contact-info">
                                <p class="mb-1 text-muted small">
                                    <i class="fas fa-envelope me-2"></i>info@zakhofc.com
                                </p>
                                <p class="mb-0 text-muted small">
                                    <i class="fas fa-phone me-2"></i>+964 750 123 4567
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <hr class="my-4 bg-secondary">
                    
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center text-md-start">
                            <p class="mb-0 text-muted">
                                &copy; ٢٠٢٥ یادگای زاخۆ. هەموو مافەکان پارێزراون.
                            </p>
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-links">
                                <a href="#" class="text-muted text-decoration-none me-3 small">Privacy Policy</a>
                                <a href="#" class="text-muted text-decoration-none me-3 small">Terms of Service</a>
                                <a href="#" class="text-muted text-decoration-none small">Cookie Policy</a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script>
                const isUserLoggedIn = ' . (isset($user) ? 'true' : 'false') . ';
            </script>
            <script src="js/cart.js"></script>
        </body>
        </html>';
    }
}