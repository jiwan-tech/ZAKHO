<?php
class AdminView {

    public function matchForm($match = null) {

        $isEdit = $match !== null;

        $title = $isEdit ? "Edit Match" : "Add Match";
        $action = $isEdit ? "update_match&id=" . $match["id"] : "insert_match";

        echo '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>'.$title.' - Admin</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>

        <body class="bg-light">

        <div class="container mt-5">
            <div class="card shadow-lg">
                <div class="card-header bg-red text-white">
                    <h3 class="mb-0">'.$title.'</h3>
                </div>

                <div class="card-body">

                    <form action="admin.php?action='.$action.'" method="POST">

                        <div class="mb-3">
                            <label class="form-label">Home Team</label>
                            <input type="text" name="home_team" class="form-control" required
                                value="'.($isEdit ? htmlspecialchars($match["home_team"]) : "").'">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Away Team</label>
                            <input type="text" name="away_team" class="form-control" required
                                value="'.($isEdit ? htmlspecialchars($match["away_team"]) : "").'">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Match Date</label>
                            <input type="datetime-local" name="match_date" class="form-control" required
                                value="'.($isEdit ? date("Y-m-d\TH:i", strtotime($match["match_date"])) : "").'">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Venue</label>
                            <input type="text" name="venue" class="form-control"
                                value="'.($isEdit ? htmlspecialchars($match["venue"]) : "").'">
                        </div>

                        <button class="btn btn-red px-4">'.$title.'</button>
                        <a href="admin.php" class="btn btn-secondary">Cancel</a>

                    </form>

                </div>
            </div>
        </div>
        </body>
        </html>';
    }
}
?>
