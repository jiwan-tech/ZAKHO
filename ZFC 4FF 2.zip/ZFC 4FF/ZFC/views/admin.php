<?php
// Session is already started in index.php, so we don't need to start it again here

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection
require_once __DIR__ . '/../config.php';
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Set charset to UTF-8
$conn->set_charset("utf8mb4");

// Check if user is logged in and is admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: index.php?action=signin");
    exit;
}

// Handle actions - check for admin_action first (passed from index.php), then fall back to action
$action = $_GET['admin_action'] ?? $_GET['action'] ?? '';
$id = $_GET['id'] ?? 0;

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    handlePostRequest($conn, $action, $id);
}

// Handle GET actions (delete)
if (isset($_GET['delete'])) {
    handleDeleteRequest($conn, $_GET['delete'], $id);
}

// Display the appropriate page
displayPage($conn, $action, $id);

$conn->close();

// ========== FUNCTIONS ==========

function handlePostRequest($conn, $action, $id) {
    switch ($action) {
        case 'add_match':
        case 'edit_match':
            $home_team = trim($_POST['home_team']);
            $away_team = trim($_POST['away_team']);
            $match_date = $_POST['match_date'];
            $venue = trim($_POST['venue']);
            $ticket_price = floatval($_POST['ticket_price']);
            $available_tickets = intval($_POST['available_tickets']);
            
            if ($home_team && $away_team && $match_date) {
                if ($action === 'add_match') {
                    $stmt = $conn->prepare("INSERT INTO matches (home_team, away_team, match_date, venue, ticket_price, available_tickets) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("ssssdi", $home_team, $away_team, $match_date, $venue, $ticket_price, $available_tickets);
                } else {
                    $stmt = $conn->prepare("UPDATE matches SET home_team=?, away_team=?, match_date=?, venue=?, ticket_price=?, available_tickets=? WHERE id=?");
                    $stmt->bind_param("ssssdii", $home_team, $away_team, $match_date, $venue, $ticket_price, $available_tickets, $id);
                }
                
                if ($stmt->execute()) {
                    $_SESSION['message'] = "Match " . ($action === 'add_match' ? 'added' : 'updated') . " successfully!";
                } else {
                    $_SESSION['error'] = "Error saving match: " . $stmt->error;
                }
            }
            break;

        case 'add_product':
        case 'edit_product':
            $name = trim($_POST['name']);
            $description = trim($_POST['description']);
            $price = floatval($_POST['price']);
            $category = trim($_POST['category']);
            $stock = intval($_POST['stock']);
            
            // Validate category against allowed values
            $allowed_categories = ['jersey', 'scarf', 'cap', 'jacket', 'other'];
            if (!in_array($category, $allowed_categories)) {
                $_SESSION['error'] = "Invalid category selected. Please choose a valid category.";
                break;
            }
            
            if ($name && $price > 0) {
                if ($action === 'add_product') {
                    $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock) VALUES (?, ?, ?, ?, ?)");
                    $stmt->bind_param("ssdsi", $name, $description, $price, $category, $stock);
                } else {
                    $stmt = $conn->prepare("UPDATE products SET name=?, description=?, price=?, category=?, stock=? WHERE id=?");
                    $stmt->bind_param("ssdsii", $name, $description, $price, $category, $stock, $id);
                }
                
                if ($stmt->execute()) {
                    $_SESSION['message'] = "Product " . ($action === 'add_product' ? 'added' : 'updated') . " successfully!";
                } else {
                    $error_msg = $stmt->error;
                    // Check if error is due to missing category in ENUM
                    if (strpos($error_msg, 'category') !== false && (strpos($error_msg, 'truncated') !== false || strpos($error_msg, 'Data truncated') !== false)) {
                        $_SESSION['error'] = "⚠️ Database schema needs to be updated!<br><br>Please run this fix script: <a href='auto_fix_database.php' target='_blank' style='color: #dc3545; font-weight: bold;'>auto_fix_database.php</a><br><br>Or manually run this SQL in phpMyAdmin:<br><code style='background:#f4f4f4;padding:10px;display:block;margin-top:10px;'>ALTER TABLE products MODIFY COLUMN category ENUM('jersey','scarf','cap','jacket','other') DEFAULT 'other';</code>";
                    } else {
                        $_SESSION['error'] = "Error saving product: " . htmlspecialchars($error_msg);
                    }
                }
            }
            break;

        case 'edit_order':
            $status = $_POST['status'];
            $stmt = $conn->prepare("UPDATE orders SET status=? WHERE id=?");
            $stmt->bind_param("si", $status, $id);
            if ($stmt->execute()) {
                $_SESSION['message'] = "Order status updated successfully!";
            }
            break;

        case 'edit_team_info':
            $name = trim($_POST['name'] ?? '');
            $name_arabic = trim($_POST['name_arabic'] ?? '');
            $founded = trim($_POST['founded'] ?? '');
            $city = trim($_POST['city'] ?? '');
            $stadium = trim($_POST['stadium'] ?? '');
            $stadium_opened = trim($_POST['stadium_opened'] ?? '');
            $capacity = trim($_POST['capacity'] ?? '');
            $league = trim($_POST['league'] ?? '');
            $nickname = trim($_POST['nickname'] ?? '');
            $nickname_arabic = trim($_POST['nickname_arabic'] ?? '');
            $colors = trim($_POST['colors'] ?? '');
            $status = trim($_POST['status'] ?? '');
            $description = trim($_POST['description'] ?? '');
            
            $stmt = $conn->prepare("UPDATE team_info SET name=?, name_arabic=?, founded=?, city=?, stadium=?, stadium_opened=?, capacity=?, league=?, nickname=?, nickname_arabic=?, colors=?, status=?, description=? WHERE id=1");
            $stmt->bind_param("sssssssssssss", $name, $name_arabic, $founded, $city, $stadium, $stadium_opened, $capacity, $league, $nickname, $nickname_arabic, $colors, $status, $description);
            if ($stmt->execute()) {
                $_SESSION['message'] = "Team information updated successfully!";
            } else {
                $_SESSION['error'] = "Error updating team info: " . $stmt->error;
            }
            break;

        case 'add_player':
        case 'edit_player':
            $name = trim($_POST['name'] ?? '');
            $position = trim($_POST['position'] ?? '');
            $number = trim($_POST['number'] ?? '');
            $nationality = trim($_POST['nationality'] ?? '');
            $role = trim($_POST['role'] ?? '');
            $is_special = isset($_POST['is_special']) ? 1 : 0;
            $display_order = intval($_POST['display_order'] ?? 0);
            
            if ($name && $position) {
                if ($action === 'add_player') {
                    $stmt = $conn->prepare("INSERT INTO players (name, position, number, nationality, role, is_special, display_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("sssssii", $name, $position, $number, $nationality, $role, $is_special, $display_order);
                } else {
                    $stmt = $conn->prepare("UPDATE players SET name=?, position=?, number=?, nationality=?, role=?, is_special=?, display_order=? WHERE id=?");
                    $stmt->bind_param("sssssiii", $name, $position, $number, $nationality, $role, $is_special, $display_order, $id);
                }
                
                if ($stmt->execute()) {
                    $_SESSION['message'] = "Player " . ($action === 'add_player' ? 'added' : 'updated') . " successfully!";
                } else {
                    $_SESSION['error'] = "Error saving player: " . $stmt->error;
                }
            }
            break;

        case 'edit_stadium_info':
            $name = trim($_POST['name'] ?? '');
            $name_kurdish = trim($_POST['name_kurdish'] ?? '');
            $location = trim($_POST['location'] ?? '');
            $capacity = trim($_POST['capacity'] ?? '');
            $opened_year = trim($_POST['opened_year'] ?? '');
            $field_size = trim($_POST['field_size'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $features = trim($_POST['features'] ?? '');
            
            $stmt = $conn->prepare("UPDATE stadium_info SET name=?, name_kurdish=?, location=?, capacity=?, opened_year=?, field_size=?, description=?, features=? WHERE id=1");
            $stmt->bind_param("ssssssss", $name, $name_kurdish, $location, $capacity, $opened_year, $field_size, $description, $features);
            if ($stmt->execute()) {
                $_SESSION['message'] = "Stadium information updated successfully!";
            } else {
                $_SESSION['error'] = "Error updating stadium info: " . $stmt->error;
            }
            break;
    }
    
    header("Location: index.php?action=admin");
    exit;
}

function handleDeleteRequest($conn, $type, $id) {
    switch ($type) {
        case 'match':
            $stmt = $conn->prepare("DELETE FROM matches WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                $_SESSION['message'] = "Match deleted successfully!";
            }
            break;
            
        case 'product':
            $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                $_SESSION['message'] = "Product deleted successfully!";
            }
            break;
            
        case 'player':
            $stmt = $conn->prepare("DELETE FROM players WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                $_SESSION['message'] = "Player deleted successfully!";
            }
            break;
    }
    
    header("Location: index.php?action=admin");
    exit;
}

function displayPage($conn, $action, $id) {
    switch ($action) {
        case 'add_match':
        case 'edit_match':
            $match = [];
            if ($action === 'edit_match' && $id) {
                $result = $conn->query("SELECT * FROM matches WHERE id = $id");
                $match = $result->fetch_assoc();
            }
            displayMatchForm($match, $action);
            break;

        case 'add_product':
        case 'edit_product':
            $product = [];
            if ($action === 'edit_product' && $id) {
                $result = $conn->query("SELECT * FROM products WHERE id = $id");
                $product = $result->fetch_assoc();
            }
            displayProductForm($product, $action);
            break;

        case 'edit_team_info':
            $result = $conn->query("SELECT * FROM team_info WHERE id = 1");
            $team_info = $result->fetch_assoc() ?: [];
            displayTeamInfoForm($team_info);
            break;

        case 'add_player':
        case 'edit_player':
            $player = [];
            if ($action === 'edit_player' && $id) {
                $result = $conn->query("SELECT * FROM players WHERE id = $id");
                $player = $result->fetch_assoc();
            }
            displayPlayerForm($player, $action);
            break;

        case 'edit_stadium_info':
            $result = $conn->query("SELECT * FROM stadium_info WHERE id = 1");
            $stadium_info = $result->fetch_assoc() ?: [];
            displayStadiumInfoForm($stadium_info);
            break;

        case 'edit_order':
            $order = [];
            if ($id) {
                $result = $conn->query("SELECT * FROM orders WHERE id = $id");
                $order = $result->fetch_assoc();
            }
            displayOrderForm($order);
            break;

        default:
            displayDashboard($conn);
            break;
    }
}

function displayDashboard($conn) {
    $matches = $conn->query("SELECT * FROM matches ORDER BY match_date DESC")->fetch_all(MYSQLI_ASSOC);
    $products = $conn->query("SELECT * FROM products ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);
    $orders = $conn->query("SELECT * FROM orders ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);
    ?>
    <!DOCTYPE html>
    <html lang="ku" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Zakho FC - Admin Panel</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: Arial, sans-serif; background: #f4f4f4; color: #333; }
            .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
            .header { background: #dc3545; color: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
            .header h1 { margin-bottom: 0; }
            .user-info { text-align: right; }
            .user-info a { color: white; margin-left: 15px; }
            .nav { background: white; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
            .nav a { margin-right: 15px; text-decoration: none; color: #dc3545; font-weight: bold; }
            .section { background: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; }
            .section h2 { color: #dc3545; margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px; }
            .btn { display: inline-block; padding: 8px 16px; background: #dc3545; color: white; text-decoration: none; border-radius: 4px; border: none; cursor: pointer; }
            .btn:hover { background: #c82333; }
            .btn-edit { background: #28a745; }
            .btn-edit:hover { background: #218838; }
            .btn-delete { background: #dc3545; }
            .btn-delete:hover { background: #c82333; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
            th { background: #f8f9fa; font-weight: bold; }
            tr:hover { background: #f8f9fa; }
            .message { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin-bottom: 20px; }
            .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 20px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div>
                    <h1>🏆 Zakho FC Admin Panel</h1>
                    <p>Manage matches, products, and orders</p>
                </div>
                <div class="user-info">
                    Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?>!
                    <a href="index.php?action=logout">Logout</a>
                </div>
            </div>

            <div class="nav">
                <a href="index.php?action=admin">Dashboard</a>
                <a href="index.php?action=admin&admin_action=add_match">Add Match</a>
                <a href="index.php?action=admin&admin_action=add_product">Add Product</a>
                <a href="index.php?action=admin&admin_action=edit_team_info">Team Info</a>
                <a href="index.php?action=admin&admin_action=add_player">Add Player</a>
                <a href="index.php?action=admin&admin_action=edit_stadium_info">Stadium Info</a>
            </div>

            <?php if (isset($_SESSION['message'])): ?>
                <div class="message"><?= $_SESSION['message'] ?></div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="error"><?= $_SESSION['error'] ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <!-- Matches Section -->
            <div class="section">
                <h2>⚽ Matches Management</h2>
                <a href="index.php?action=admin&admin_action=add_match" class="btn">Add New Match</a>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Match</th>
                            <th>Date</th>
                            <th>Venue</th>
                            <th>Tickets</th>
                            <th>Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($matches as $match): ?>
                        <tr>
                            <td><?= $match['id'] ?></td>
                            <td><?= htmlspecialchars($match['home_team']) ?> vs <?= htmlspecialchars($match['away_team']) ?></td>
                            <td><?= date('M j, Y H:i', strtotime($match['match_date'])) ?></td>
                            <td><?= htmlspecialchars($match['venue']) ?></td>
                            <td><?= $match['available_tickets'] ?></td>
                            <td>$<?= $match['ticket_price'] ?></td>
                            <td>
                                <a href="index.php?action=admin&admin_action=edit_match&id=<?= $match['id'] ?>" class="btn btn-edit">Edit</a>
                                <a href="index.php?action=admin&delete=match&id=<?= $match['id'] ?>" class="btn btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Products Section -->
            <div class="section">
                <h2>🛍️ Products Management</h2>
                <a href="index.php?action=admin&admin_action=add_product" class="btn">Add New Product</a>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?= $product['id'] ?></td>
                            <td><?= htmlspecialchars($product['name']) ?></td>
                            <td><?= ucfirst($product['category']) ?></td>
                            <td>$<?= $product['price'] ?></td>
                            <td><?= $product['stock'] ?></td>
                            <td>
                                <a href="index.php?action=admin&admin_action=edit_product&id=<?= $product['id'] ?>" class="btn btn-edit">Edit</a>
                                <a href="index.php?action=admin&delete=product&id=<?= $product['id'] ?>" class="btn btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Orders Section -->
            <div class="section">
                <h2>📦 Orders Management</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= $order['id'] ?></td>
                            <td><?= ucfirst($order['order_type']) ?></td>
                            <td>$<?= $order['total_amount'] ?></td>
                            <td><?= htmlspecialchars($order['phone'] ?? 'N/A') ?></td>
                            <td><?= ucfirst($order['status']) ?></td>
                            <td><?= date('M j, Y', strtotime($order['created_at'])) ?></td>
                            <td>
                                <a href="index.php?action=admin&admin_action=edit_order&id=<?= $order['id'] ?>" class="btn btn-edit">Update Status</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Team Info Section -->
            <div class="section">
                <h2>🏆 Team Information Management</h2>
                <a href="index.php?action=admin&admin_action=edit_team_info" class="btn">Edit Team Information</a>
                <?php
                $team_info = $conn->query("SELECT * FROM team_info WHERE id = 1")->fetch_assoc();
                if ($team_info):
                ?>
                <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 5px;">
                    <p><strong>Name:</strong> <?= htmlspecialchars($team_info['name'] ?? 'N/A') ?></p>
                    <p><strong>Founded:</strong> <?= htmlspecialchars($team_info['founded'] ?? 'N/A') ?></p>
                    <p><strong>Stadium:</strong> <?= htmlspecialchars($team_info['stadium'] ?? 'N/A') ?></p>
                    <p><strong>League:</strong> <?= htmlspecialchars($team_info['league'] ?? 'N/A') ?></p>
                </div>
                <?php endif; ?>
            </div>

            <!-- Players Section -->
            <div class="section">
                <h2>👥 Players Management</h2>
                <a href="index.php?action=admin&admin_action=add_player" class="btn">Add New Player</a>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Number</th>
                            <th>Nationality</th>
                            <th>Special</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $players = $conn->query("SELECT * FROM players ORDER BY display_order, position, number")->fetch_all(MYSQLI_ASSOC);
                        foreach ($players as $player): 
                        ?>
                        <tr>
                            <td><?= $player['id'] ?></td>
                            <td><?= htmlspecialchars($player['name']) ?></td>
                            <td><?= htmlspecialchars($player['position']) ?></td>
                            <td><?= htmlspecialchars($player['number']) ?></td>
                            <td><?= htmlspecialchars($player['nationality']) ?></td>
                            <td><?= $player['is_special'] ? '⭐ Legend' : '-' ?></td>
                            <td>
                                <a href="index.php?action=admin&admin_action=edit_player&id=<?= $player['id'] ?>" class="btn btn-edit">Edit</a>
                                <a href="index.php?action=admin&delete=player&id=<?= $player['id'] ?>" class="btn btn-delete" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Stadium Info Section -->
            <div class="section">
                <h2>🏟️ Stadium Information Management</h2>
                <a href="index.php?action=admin&admin_action=edit_stadium_info" class="btn">Edit Stadium Information</a>
                <?php
                $stadium_info = $conn->query("SELECT * FROM stadium_info WHERE id = 1")->fetch_assoc();
                if ($stadium_info):
                ?>
                <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 5px;">
                    <p><strong>Name:</strong> <?= htmlspecialchars($stadium_info['name'] ?? 'N/A') ?></p>
                    <p><strong>Capacity:</strong> <?= htmlspecialchars($stadium_info['capacity'] ?? 'N/A') ?></p>
                    <p><strong>Opened:</strong> <?= htmlspecialchars($stadium_info['opened_year'] ?? 'N/A') ?></p>
                    <p><strong>Location:</strong> <?= htmlspecialchars($stadium_info['location'] ?? 'N/A') ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </body>
    </html>
    <?php
}

function displayMatchForm($match, $action) {
    $isEdit = $action === 'edit_match';
    ?>
    <!DOCTYPE html>
    <html lang="ku" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $isEdit ? 'Edit Match' : 'Add Match' ?> - Zakho FC Admin</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: Arial, sans-serif; background: #f4f4f4; color: #333; }
            .container { max-width: 800px; margin: 0 auto; padding: 20px; }
            .header { background: #dc3545; color: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
            .header h1 { margin-bottom: 0; }
            .user-info a { color: white; }
            .form-section { background: white; padding: 30px; border-radius: 8px; }
            .form-group { margin-bottom: 20px; }
            label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }
            input, select, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; }
            .btn { display: inline-block; padding: 10px 20px; background: #dc3545; color: white; text-decoration: none; border-radius: 4px; border: none; cursor: pointer; margin-right: 10px; }
            .btn:hover { background: #c82333; }
            .btn-cancel { background: #6c757d; }
            .btn-cancel:hover { background: #5a6268; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div>
                    <h1>⚽ <?= $isEdit ? 'Edit Match' : 'Add New Match' ?></h1>
                    <p><a href="index.php?action=admin" style="color: white;">← Back to Dashboard</a></p>
                </div>
                <div class="user-info">
                    Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?>!
                    <a href="index.php?action=logout">Logout</a>
                </div>
            </div>

            <div class="form-section">
                <form method="POST" action="index.php?action=admin&admin_action=<?= $action ?><?= $isEdit ? '&id=' . $match['id'] : '' ?>">
                    <div class="form-group">
                        <label for="home_team">Home Team</label>
                        <input type="text" id="home_team" name="home_team" value="<?= htmlspecialchars($match['home_team'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="away_team">Away Team</label>
                        <input type="text" id="away_team" name="away_team" value="<?= htmlspecialchars($match['away_team'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="match_date">Match Date & Time</label>
                        <input type="datetime-local" id="match_date" name="match_date" value="<?= isset($match['match_date']) ? date('Y-m-d\TH:i', strtotime($match['match_date'])) : '' ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="venue">Venue</label>
                        <input type="text" id="venue" name="venue" value="<?= htmlspecialchars($match['venue'] ?? 'Zakho Arena') ?>">
                    </div>

                    <div class="form-group">
                        <label for="ticket_price">Ticket Price ($)</label>
                        <input type="number" id="ticket_price" name="ticket_price" step="0.01" min="0" value="<?= $match['ticket_price'] ?? 25.00 ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="available_tickets">Available Tickets</label>
                        <input type="number" id="available_tickets" name="available_tickets" min="0" value="<?= $match['available_tickets'] ?? 1000 ?>" required>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn"><?= $isEdit ? 'Update Match' : 'Add Match' ?></button>
                        <a href="index.php?action=admin" class="btn btn-cancel">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
    </html>
    <?php
}

function displayProductForm($product, $action) {
    $isEdit = $action === 'edit_product';
    $categories = ['jersey', 'scarf', 'cap', 'jacket', 'other'];
    ?>
    <!DOCTYPE html>
    <html lang="ku" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $isEdit ? 'Edit Product' : 'Add Product' ?> - Zakho FC Admin</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: Arial, sans-serif; background: #f4f4f4; color: #333; }
            .container { max-width: 800px; margin: 0 auto; padding: 20px; }
            .header { background: #dc3545; color: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
            .header h1 { margin-bottom: 0; }
            .user-info a { color: white; }
            .form-section { background: white; padding: 30px; border-radius: 8px; }
            .form-group { margin-bottom: 20px; }
            label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }
            input, select, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; }
            .btn { display: inline-block; padding: 10px 20px; background: #dc3545; color: white; text-decoration: none; border-radius: 4px; border: none; cursor: pointer; margin-right: 10px; }
            .btn:hover { background: #c82333; }
            .btn-cancel { background: #6c757d; }
            .btn-cancel:hover { background: #5a6268; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div>
                    <h1>🛍️ <?= $isEdit ? 'Edit Product' : 'Add New Product' ?></h1>
                    <p><a href="index.php?action=admin" style="color: white;">← Back to Dashboard</a></p>
                </div>
                <div class="user-info">
                    Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?>!
                    <a href="index.php?action=logout">Logout</a>
                </div>
            </div>

            <div class="form-section">
                <form method="POST" action="index.php?action=admin&admin_action=<?= $action ?><?= $isEdit ? '&id=' . $product['id'] : '' ?>">
                    <div class="form-group">
                        <label for="name">Product Name</label>
                        <input type="text" id="name" name="name" value="<?= htmlspecialchars($product['name'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="4"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="price">Price ($)</label>
                        <input type="number" id="price" name="price" step="0.01" min="0" value="<?= $product['price'] ?? '' ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="category">Category</label>
                        <select id="category" name="category" required>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category ?>" <?= isset($product['category']) && $product['category'] === $category ? 'selected' : '' ?>>
                                    <?= ucfirst($category) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="stock">Stock Quantity</label>
                        <input type="number" id="stock" name="stock" min="0" value="<?= $product['stock'] ?? 0 ?>" required>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn"><?= $isEdit ? 'Update Product' : 'Add Product' ?></button>
                        <a href="index.php?action=admin" class="btn btn-cancel">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
    </html>
    <?php
}

function displayOrderForm($order) {
    $statuses = ['pending', 'confirmed', 'shipped', 'delivered'];
    ?>
    <!DOCTYPE html>
    <html lang="ku" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Update Order Status - Zakho FC Admin</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: Arial, sans-serif; background: #f4f4f4; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #dc3545; color: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
            .header h1 { margin-bottom: 0; }
            .user-info a { color: white; }
            .form-section { background: white; padding: 30px; border-radius: 8px; }
            .form-group { margin-bottom: 20px; }
            label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }
            select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; }
            .btn { display: inline-block; padding: 10px 20px; background: #dc3545; color: white; text-decoration: none; border-radius: 4px; border: none; cursor: pointer; margin-right: 10px; }
            .btn:hover { background: #c82333; }
            .btn-cancel { background: #6c757d; }
            .btn-cancel:hover { background: #5a6268; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div>
                    <h1>📦 Update Order Status</h1>
                    <p><a href="index.php?action=admin" style="color: white;">← Back to Dashboard</a></p>
                </div>
                <div class="user-info">
                    Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?>!
                    <a href="index.php?action=logout">Logout</a>
                </div>
            </div>

            <div class="form-section">
                <form method="POST" action="index.php?action=admin&admin_action=edit_order&id=<?= $order['id'] ?>">
                    <div class="form-group">
                        <label for="status">Order Status</label>
                        <select id="status" name="status" required>
                            <?php foreach ($statuses as $status): ?>
                                <option value="<?= $status ?>" <?= $order['status'] === $status ? 'selected' : '' ?>>
                                    <?= ucfirst($status) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn">Update Status</button>
                        <a href="index.php?action=admin" class="btn btn-cancel">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
    </html>
    <?php
}

function displayTeamInfoForm($team_info) {
    $team_info = $team_info ?: [];
    ?>
    <!DOCTYPE html>
    <html lang="ku" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Team Information - Admin</title>
        <link rel="stylesheet" href="../css/style.css">
        <style>
            body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
            .form-container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; }
            .form-group { margin-bottom: 20px; }
            label { display: block; margin-bottom: 5px; font-weight: bold; }
            input[type="text"], input[type="number"], textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
            textarea { min-height: 100px; }
            .btn { padding: 10px 20px; background: #dc3545; color: white; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }
            .btn:hover { background: #c82333; }
            .btn-cancel { background: #6c757d; }
        </style>
    </head>
    <body>
        <div class="form-container">
            <h1>Edit Team Information</h1>
            <form method="POST" action="index.php?action=admin&admin_action=edit_team_info">
                <div class="form-group">
                    <label>Team Name (English)</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($team_info['name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Team Name (Arabic)</label>
                    <input type="text" name="name_arabic" value="<?= htmlspecialchars($team_info['name_arabic'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Founded Year</label>
                    <input type="text" name="founded" value="<?= htmlspecialchars($team_info['founded'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>City</label>
                    <input type="text" name="city" value="<?= htmlspecialchars($team_info['city'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Stadium</label>
                    <input type="text" name="stadium" value="<?= htmlspecialchars($team_info['stadium'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Stadium Opened</label>
                    <input type="text" name="stadium_opened" value="<?= htmlspecialchars($team_info['stadium_opened'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Capacity</label>
                    <input type="text" name="capacity" value="<?= htmlspecialchars($team_info['capacity'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>League</label>
                    <input type="text" name="league" value="<?= htmlspecialchars($team_info['league'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Nickname</label>
                    <input type="text" name="nickname" value="<?= htmlspecialchars($team_info['nickname'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Nickname (Arabic)</label>
                    <input type="text" name="nickname_arabic" value="<?= htmlspecialchars($team_info['nickname_arabic'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Colors</label>
                    <input type="text" name="colors" value="<?= htmlspecialchars($team_info['colors'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <textarea name="status"><?= htmlspecialchars($team_info['status'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <label>Description (Kurdish)</label>
                    <textarea name="description" rows="8"><?= htmlspecialchars($team_info['description'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">Update Team Information</button>
                    <a href="index.php?action=admin" class="btn btn-cancel">Cancel</a>
                </div>
            </form>
        </div>
    </body>
    </html>
    <?php
}

function displayPlayerForm($player, $action) {
    $isEdit = $action === 'edit_player';
    $player = $player ?: [];
    ?>
    <!DOCTYPE html>
    <html lang="ku" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $isEdit ? 'Edit' : 'Add' ?> Player - Admin</title>
        <link rel="stylesheet" href="../css/style.css">
        <style>
            body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
            .form-container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; }
            .form-group { margin-bottom: 20px; }
            label { display: block; margin-bottom: 5px; font-weight: bold; }
            input[type="text"], input[type="number"], select, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
            textarea { min-height: 80px; }
            .btn { padding: 10px 20px; background: #dc3545; color: white; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }
            .btn:hover { background: #c82333; }
            .btn-cancel { background: #6c757d; }
        </style>
    </head>
    <body>
        <div class="form-container">
            <h1><?= $isEdit ? 'Edit' : 'Add' ?> Player</h1>
            <form method="POST" action="index.php?action=admin&admin_action=<?= $action ?><?= $isEdit ? '&id=' . $player['id'] : '' ?>">
                <div class="form-group">
                    <label>Player Name *</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($player['name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Position *</label>
                    <select name="position" required>
                        <option value="Goalkeeper" <?= ($player['position'] ?? '') === 'Goalkeeper' ? 'selected' : '' ?>>Goalkeeper</option>
                        <option value="Defender" <?= ($player['position'] ?? '') === 'Defender' ? 'selected' : '' ?>>Defender</option>
                        <option value="Midfielder" <?= ($player['position'] ?? '') === 'Midfielder' ? 'selected' : '' ?>>Midfielder</option>
                        <option value="Forward" <?= ($player['position'] ?? '') === 'Forward' ? 'selected' : '' ?>>Forward</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Jersey Number</label>
                    <input type="text" name="number" value="<?= htmlspecialchars($player['number'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Nationality</label>
                    <input type="text" name="nationality" value="<?= htmlspecialchars($player['nationality'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Role/Description</label>
                    <textarea name="role"><?= htmlspecialchars($player['role'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_special" value="1" <?= ($player['is_special'] ?? 0) ? 'checked' : '' ?>>
                        Mark as Special (Legend)
                    </label>
                </div>
                <div class="form-group">
                    <label>Display Order</label>
                    <input type="number" name="display_order" value="<?= $player['display_order'] ?? 0 ?>" min="0">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn"><?= $isEdit ? 'Update Player' : 'Add Player' ?></button>
                    <a href="index.php?action=admin" class="btn btn-cancel">Cancel</a>
                </div>
            </form>
        </div>
    </body>
    </html>
    <?php
}

function displayStadiumInfoForm($stadium_info) {
    $stadium_info = $stadium_info ?: [];
    ?>
    <!DOCTYPE html>
    <html lang="ku" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Stadium Information - Admin</title>
        <link rel="stylesheet" href="../css/style.css">
        <style>
            body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
            .form-container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; }
            .form-group { margin-bottom: 20px; }
            label { display: block; margin-bottom: 5px; font-weight: bold; }
            input[type="text"], textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
            textarea { min-height: 100px; }
            .btn { padding: 10px 20px; background: #dc3545; color: white; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }
            .btn:hover { background: #c82333; }
            .btn-cancel { background: #6c757d; }
        </style>
    </head>
    <body>
        <div class="form-container">
            <h1>Edit Stadium Information</h1>
            <form method="POST" action="index.php?action=admin&admin_action=edit_stadium_info">
                <div class="form-group">
                    <label>Stadium Name (English)</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($stadium_info['name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Stadium Name (Kurdish)</label>
                    <input type="text" name="name_kurdish" value="<?= htmlspecialchars($stadium_info['name_kurdish'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="location" value="<?= htmlspecialchars($stadium_info['location'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Capacity</label>
                    <input type="text" name="capacity" value="<?= htmlspecialchars($stadium_info['capacity'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Opened Year</label>
                    <input type="text" name="opened_year" value="<?= htmlspecialchars($stadium_info['opened_year'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Field Size</label>
                    <input type="text" name="field_size" value="<?= htmlspecialchars($stadium_info['field_size'] ?? '') ?>" placeholder="e.g., 105m x 68m">
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="5"><?= htmlspecialchars($stadium_info['description'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <label>Features</label>
                    <textarea name="features" rows="5"><?= htmlspecialchars($stadium_info['features'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">Update Stadium Information</button>
                    <a href="index.php?action=admin" class="btn btn-cancel">Cancel</a>
                </div>
            </form>
        </div>
    </body>
    </html>
    <?php
}
?>