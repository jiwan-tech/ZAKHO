<?php
class AdminView {

    public function productForm($product = null) {

        $isEdit = $product !== null;

        $title = $isEdit ? "Edit Product" : "Add Product";
        $action = $isEdit ? "update_product&id=" . $product["id"] : "insert_product";

        echo '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>'.$title.' - Admin</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>

        <body class="bg-light">

        <div class="container mt-5">
            <div class="card shadow-lg">
                <div class="card-header bg-red text-white">
                    <h3 class="mb-0">'.$title.'</h3>
                </div>

                <div class="card-body">

                    <form action="admin.php?action='.$action.'" method="POST" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" name="name" class="form-control" required
                                value="'.($isEdit ? htmlspecialchars($product["name"]) : "").'">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="3">'.($isEdit ? htmlspecialchars($product["description"]) : "").'</textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="number" step="0.01" name="price" class="form-control" required
                                value="'.($isEdit ? $product["price"] : "").'">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Stock</label>
                            <input type="number" name="stock" class="form-control" required
                                value="'.($isEdit ? $product["stock"] : "").'">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Image</label>';

                            if ($isEdit && !empty($product["image"])) {
                                echo '<div class="mb-2"><img src="img/products/'.$product["image"].'" width="120"></div>';
                            }

                        echo '
                            <input type="file" name="image" class="form-control">
                        </div>

                        <button class="btn btn-red px-4">'.$title.'</button>
                        <a href="admin.php" class="btn btn-secondary">Cancel</a>

                    </form>

                </div>
            </div>
        </div>
        </body>
        </html>';
    }
}
?>
