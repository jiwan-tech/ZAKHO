<?php
// Script to update the products table to include 'jacket' category
// Run this file through your web browser: http://localhost:8888/ZFC%204FF/ZFC/update_database.php

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Update - Zakho FC</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #dc3545;
        }
        .success {
            color: #28a745;
            background: #d4edda;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .error {
            color: #dc3545;
            background: #f8d7da;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .info {
            background: #d1ecf1;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        code {
            background: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Database Schema Update</h1>
        
        <?php
        require_once __DIR__ . '/config.php';

        try {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error);
            }

            // Check current ENUM values
            $check_sql = "SHOW COLUMNS FROM products WHERE Field = 'category'";
            $result = $conn->query($check_sql);
            $row = $result->fetch_assoc();
            $current_enum = $row['Type'];
            
            echo '<div class="info">';
            echo '<strong>Current category ENUM:</strong><br>';
            echo '<code>' . htmlspecialchars($current_enum) . '</code>';
            echo '</div>';

            // Check if 'jacket' is already in the ENUM
            if (strpos($current_enum, 'jacket') !== false) {
                echo '<div class="success">';
                echo '✓ Category "jacket" is already in the database schema. No update needed!';
                echo '</div>';
            } else {
                // Update the category ENUM to include 'jacket'
                $sql = "ALTER TABLE products MODIFY COLUMN category ENUM('jersey','scarf','cap','jacket','other') DEFAULT 'other'";

                if ($conn->query($sql) === TRUE) {
                    echo '<div class="success">';
                    echo '✓ <strong>Database updated successfully!</strong><br>';
                    echo 'Category "jacket" has been added to the products table.';
                    echo '</div>';
                } else {
                    throw new Exception("Error updating database: " . $conn->error);
                }
            }

            $conn->close();
            
        } catch (Exception $e) {
            echo '<div class="error">';
            echo '✗ <strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
            echo '<div class="info">';
            echo '<strong>Manual Update Instructions:</strong><br>';
            echo '1. Open phpMyAdmin: <a href="http://localhost:8888/phpMyAdmin/" target="_blank">http://localhost:8888/phpMyAdmin/</a><br>';
            echo '2. Select the <code>zakho_fc</code> database<br>';
            echo '3. Click on the SQL tab<br>';
            echo '4. Run this SQL command:<br>';
            echo '<code style="display:block;margin-top:10px;padding:10px;background:#f4f4f4;">';
            echo "ALTER TABLE products MODIFY COLUMN category ENUM('jersey','scarf','cap','jacket','other') DEFAULT 'other';";
            echo '</code>';
            echo '</div>';
        }
        ?>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
            <p><a href="index.php?action=admin">← Back to Admin Panel</a></p>
        </div>
    </div>
</body>
</html>

