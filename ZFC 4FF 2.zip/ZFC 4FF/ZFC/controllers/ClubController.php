<?php
class ClubController {
    private $model;
    private $view;
    
    public function __construct() {
        // Remove session_start() from here since it's already started in index.php
        $this->model = new ClubModel();
        $this->view = new ClubView();
    }
    
    private function handleAdmin() {
        // Check if user is logged in and is admin
        if (!isset($_SESSION['user']) || !$this->model->isUserAdmin($_SESSION['user']['id'])) {
            header('Location: index.php?action=signin');
            exit;
        }
        
        // Include and run the admin panel
        require_once __DIR__ . '/../views/admin.php';
        exit;
    }
    
    public function handleRequest() {
        $action = $_GET['action'] ?? 'home';
        
        switch($action) {
            case 'signin':
                $this->handleSignin();
                break;
            case 'signup':
                $this->handleSignup();
                break;
            case 'logout':
                $this->handleLogout();
                break;
            case 'admin':
                $this->handleAdmin();
                break;
            case 'cart':
                $this->showCart();
                break;
            case 'add_to_cart':
                $this->handleAddToCart();
                break;
            case 'update_cart':
                $this->handleUpdateCart();
                break;
            case 'remove_from_cart':
                $this->handleRemoveFromCart();
                break;
            case 'checkout':
                $this->handleCheckout();
                break;
            case 'orders':
                $this->showOrders();
                break;
            case 'process_order':
                $this->processOrder();
                break;
            case 'get_cart_count':
                $this->getCartCount();
                break;
            case 'product':
                $this->showProduct();
                break;
            case 'account':
                $this->showAccount();
                break;
            case 'edit_account':
                $this->handleEditAccount();
                break;
            case 'delete_account':
                $this->handleDeleteAccount();
                break;
            case 'stadium':
                $this->showStadium();
                break;
            case 'team':
                $this->showTeam();
                break;
            case 'home':
            default:
                $this->showHomepage();
                break;
        }
    }
    
    private function showStadium() {
        $this->view->showStadiumPage();
    }
    
    private function showTeam() {
        $this->view->showTeamPage();
    }
    
    private function showHomepage() {
        $upcoming_matches = $this->model->getUpcomingMatches();
        $featured_products = $this->model->getFeaturedProducts();
        $all_products = $this->model->getAllProducts();
        $user = $_SESSION['user'] ?? null;
        
        $this->view->showHomepage($upcoming_matches, $featured_products, $all_products, $user);
    }
    
    private function handleSignin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            
            if (empty($email) || empty($password)) {
                $this->view->showLoginForm('Please fill in all fields');
                return;
            }
            
            // Validate email format
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $this->view->showLoginForm('Please enter a valid email address');
                return;
            }
            
            $user = $this->model->getUserByEmail($email);
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'username' => $user['username'],
                    'role' => $user['role'] ?? 'fan'
                ];
                
                // Redirect all users to homepage after login
                header('Location: index.php');
                exit;
            } else {
                $this->view->showLoginForm('Invalid email or password');
            }
        } else {
            $this->view->showLoginForm();
        }
    }
    
    private function handleSignup() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            
            if (empty($name) || empty($username) || empty($email) || empty($password)) {
                $this->view->showSignupForm('All fields are required');
                return;
            }
            
            // Validate email format
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $this->view->showSignupForm('Please enter a valid email address');
                return;
            }
            
            // Validate password strength
            if (strlen($password) < 6) {
                $this->view->showSignupForm('Password must be at least 6 characters long');
                return;
            }
            
            // Validate username format (alphanumeric and underscores only)
            if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
                $this->view->showSignupForm('Username can only contain letters, numbers, and underscores');
                return;
            }
            
            $userData = [
                'name' => htmlspecialchars($name, ENT_QUOTES, 'UTF-8'),
                'username' => htmlspecialchars($username, ENT_QUOTES, 'UTF-8'),
                'email' => filter_var($email, FILTER_SANITIZE_EMAIL),
                'password' => $password
            ];
            
            if ($this->model->createUser($userData)) {
                // Get the new user to set session
                $user = $this->model->getUserByEmail($email);
                if ($user) {
                    $_SESSION['user'] = [
                        'id' => $user['id'],
                        'name' => $user['name'],
                        'email' => $user['email'],
                        'username' => $user['username'],
                        'role' => $user['role'] ?? 'fan'
                    ];
                }
                
                header('Location: index.php');
                exit;
            } else {
                $this->view->showSignupForm('Registration failed. Email or username may already exist.');
            }
        } else {
            $this->view->showSignupForm();
        }
    }
    
    private function handleLogout() {
        // Clear all session data
        $_SESSION = [];
        
        // Destroy the session cookie
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        // Destroy the session
        session_destroy();
        
        header('Location: index.php');
        exit;
    }
    
    private function showCart() {
        if (!isset($_SESSION['user'])) {
            header('Location: index.php?action=signin');
            exit;
        }
        
        $user_id = (int)$_SESSION['user']['id'];
        $cart_items = $this->model->getCartItems($user_id);
        $this->view->showCart($cart_items);
    }
    
    private function handleAddToCart() {
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['user'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            exit;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request method']);
            exit;
        }
        
        $user_id = (int)$_SESSION['user']['id'];
        $item_type = trim($_POST['item_type'] ?? '');
        $product_id = $_POST['product_id'] ?? null;
        $match_id = $_POST['match_id'] ?? null;
        $quantity = (int)($_POST['quantity'] ?? 1);
        
        // Validate required fields
        if (empty($item_type) || !in_array($item_type, ['product', 'ticket'])) {
            echo json_encode(['success' => false, 'message' => 'Invalid item type']);
            exit;
        }
        
        if ($item_type === 'product' && (empty($product_id) || !is_numeric($product_id))) {
            echo json_encode(['success' => false, 'message' => 'Product ID is required for products']);
            exit;
        }
        
        if ($item_type === 'ticket' && (empty($match_id) || !is_numeric($match_id))) {
            echo json_encode(['success' => false, 'message' => 'Match ID is required for tickets']);
            exit;
        }
        
        // Validate quantity
        if ($quantity <= 0 || $quantity > 100) {
            echo json_encode(['success' => false, 'message' => 'Quantity must be between 1 and 100']);
            exit;
        }
        
        // Convert to integers or null
        $product_id = $item_type === 'product' ? (int)$product_id : null;
        $match_id = $item_type === 'ticket' ? (int)$match_id : null;
        
        if ($this->model->addToCart($user_id, $item_type, $product_id, $match_id, $quantity)) {
            echo json_encode(['success' => true, 'message' => 'Item added to cart']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to add item to cart. Please try again.']);
        }
        exit;
    }
    
    private function handleUpdateCart() {
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['user'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            exit;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request method']);
            exit;
        }
        
        $cart_id = (int)($_POST['cart_id'] ?? 0);
        $quantity = (int)($_POST['quantity'] ?? 1);
        
        if ($cart_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid cart item ID']);
            exit;
        }
        
        if ($quantity < 0 || $quantity > 100) {
            echo json_encode(['success' => false, 'message' => 'Quantity must be between 0 and 100']);
            exit;
        }
        
        if ($this->model->updateCartItem($cart_id, $quantity)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update cart']);
        }
        exit;
    }
    
    private function handleRemoveFromCart() {
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['user'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            exit;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request method']);
            exit;
        }
        
        $cart_id = (int)($_POST['cart_id'] ?? 0);
        
        if ($cart_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid cart item ID']);
            exit;
        }
        
        if ($this->model->removeFromCart($cart_id)) {
            echo json_encode(['success' => true, 'message' => 'Item removed from cart']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to remove item']);
        }
        exit;
    }
    
    private function getCartCount() {
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['user'])) {
            echo json_encode(['success' => true, 'count' => 0]);
            exit;
        }
        
        $user_id = (int)$_SESSION['user']['id'];
        $cart_items = $this->model->getCartItems($user_id);
        $count = 0;
        
        foreach ($cart_items as $item) {
            $count += (int)($item['quantity'] ?? 0);
        }
        
        echo json_encode(['success' => true, 'count' => $count]);
        exit;
    }
    
    private function handleCheckout() {
        if (!isset($_SESSION['user'])) {
            header('Location: index.php?action=signin');
            exit;
        }
        
        $user_id = (int)$_SESSION['user']['id'];
        $all_cart_items = $this->model->getCartItems($user_id);
        
        if (empty($all_cart_items)) {
            header('Location: index.php?action=cart');
            exit;
        }
        
        // Get selected items from URL parameter or session
        $selected_item_ids = [];
        if (isset($_GET['items']) && !empty($_GET['items'])) {
            $selected_item_ids = array_map('intval', explode(',', $_GET['items']));
        } elseif (isset($_SESSION['selected_cart_items'])) {
            $selected_item_ids = array_map('intval', $_SESSION['selected_cart_items']);
            unset($_SESSION['selected_cart_items']);
        }
        
        // Filter cart items to only include selected ones
        $cart_items = [];
        if (!empty($selected_item_ids)) {
            foreach ($all_cart_items as $item) {
                if (in_array((int)$item['id'], $selected_item_ids)) {
                    $cart_items[] = $item;
                }
            }
        } else {
            // If no selection, use all items (backward compatibility)
            $cart_items = $all_cart_items;
        }
        
        if (empty($cart_items)) {
            header('Location: index.php?action=cart');
            exit;
        }
        
        // Store selected items in session for order processing
        $_SESSION['selected_cart_items'] = $selected_item_ids;
        
        $this->view->showCheckout($cart_items);
    }
    
    private function processOrder() {
        header('Content-Type: application/json');
        
        if (!isset($_SESSION['user'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            exit;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'message' => 'Invalid request method']);
            exit;
        }
        
        $user_id = (int)$_SESSION['user']['id'];
        $shipping_address = trim($_POST['shipping_address'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $payment_method = trim($_POST['payment_method'] ?? 'cash');
        
        // Validate required fields
        if (empty($shipping_address)) {
            echo json_encode(['success' => false, 'message' => 'Shipping address is required']);
            exit;
        }
        
        if (empty($phone)) {
            echo json_encode(['success' => false, 'message' => 'Phone number is required']);
            exit;
        }
        
        // Validate payment method
        $allowed_payment_methods = ['cash', 'card', 'mobile_payment'];
        if (!in_array($payment_method, $allowed_payment_methods)) {
            echo json_encode(['success' => false, 'message' => 'Invalid payment method']);
            exit;
        }
        
        // Validate card details if card payment is selected
        if ($payment_method === 'card') {
            $card_number = trim($_POST['card_number'] ?? '');
            $card_expiry = trim($_POST['card_expiry'] ?? '');
            $card_cvv = trim($_POST['card_cvv'] ?? '');
            
            if (empty($card_number) || empty($card_expiry) || empty($card_cvv)) {
                echo json_encode(['success' => false, 'message' => 'Please enter all card details']);
                exit;
            }
            
            // Basic card number validation (remove spaces and check length)
            $card_number_clean = preg_replace('/\s+/', '', $card_number);
            if (!preg_match('/^[0-9]{13,19}$/', $card_number_clean)) {
                echo json_encode(['success' => false, 'message' => 'Please enter a valid card number']);
                exit;
            }
            
            // Validate expiry date format (MM/YY)
            if (!preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $card_expiry)) {
                echo json_encode(['success' => false, 'message' => 'Please enter a valid expiry date (MM/YY)']);
                exit;
            }
            
            // Validate CVV
            if (!preg_match('/^[0-9]{3,4}$/', $card_cvv)) {
                echo json_encode(['success' => false, 'message' => 'Please enter a valid CVV']);
                exit;
            }
        }
        
        // Sanitize shipping address
        $shipping_address = htmlspecialchars($shipping_address, ENT_QUOTES, 'UTF-8');
        
        // Basic phone validation
        if (!preg_match('/^[0-9+\-\s()]{10,}$/', $phone)) {
            echo json_encode(['success' => false, 'message' => 'Please enter a valid phone number']);
            exit;
        }
        
        // Sanitize phone number
        $phone = htmlspecialchars($phone, ENT_QUOTES, 'UTF-8');
        
        $all_cart_items = $this->model->getCartItems($user_id);
        
        if (empty($all_cart_items)) {
            echo json_encode(['success' => false, 'message' => 'Cart is empty']);
            exit;
        }
        
        // Get selected items from session or POST
        $selected_item_ids = [];
        if (isset($_SESSION['selected_cart_items']) && !empty($_SESSION['selected_cart_items'])) {
            $selected_item_ids = array_map('intval', $_SESSION['selected_cart_items']);
        } elseif (isset($_POST['selected_items']) && is_array($_POST['selected_items'])) {
            $selected_item_ids = array_map('intval', $_POST['selected_items']);
        }
        
        // Filter cart items to only include selected ones
        $cart_items = [];
        if (!empty($selected_item_ids)) {
            foreach ($all_cart_items as $item) {
                if (in_array((int)$item['id'], $selected_item_ids)) {
                    $cart_items[] = $item;
                }
            }
        } else {
            // If no selection, use all items (backward compatibility)
            $cart_items = $all_cart_items;
        }
        
        if (empty($cart_items)) {
            echo json_encode(['success' => false, 'message' => 'No items selected for order']);
            exit;
        }
        
        // Calculate total and prepare order items
        $total_amount = 0;
        $order_items = [];
        $order_type = 'product'; // Default
        
        foreach ($cart_items as $item) {
            $item_type = $item['item_type'] ?? '';
            $price = 0;
            
            if ($item_type === 'product') {
                $price = (float)($item['product_price'] ?? 0);
            } elseif ($item_type === 'ticket') {
                $price = (float)($item['ticket_price'] ?? 0);
            }
            
            $quantity = (int)($item['quantity'] ?? 0);
            $total_amount += $price * $quantity;
            
            $order_items[] = [
                'item_type' => $item_type,
                'product_id' => !empty($item['product_id']) ? (int)$item['product_id'] : null,
                'match_id' => !empty($item['match_id']) ? (int)$item['match_id'] : null,
                'quantity' => $quantity,
                'unit_price' => $price
            ];
            
            if ($item_type === 'ticket') {
                $order_type = 'ticket';
            }
        }
        
        // Validate that we have items with valid prices
        if ($total_amount <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid cart items or prices']);
            exit;
        }
        
        $order_id = $this->model->createOrder($user_id, $order_type, $total_amount, $shipping_address, $phone, $payment_method, $order_items, $selected_item_ids);
        
        if ($order_id) {
            // Clear selected items from session
            unset($_SESSION['selected_cart_items']);
            echo json_encode(['success' => true, 'order_id' => $order_id, 'message' => 'Order placed successfully!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to place order. Please try again.']);
        }
        exit;
    }
    
    private function showOrders() {
        if (!isset($_SESSION['user'])) {
            header('Location: index.php?action=signin');
            exit;
        }
        
        $user_id = (int)$_SESSION['user']['id'];
        $orders = $this->model->getUserOrders($user_id);
        $this->view->showOrders($orders);
    }
    
    private function showProduct() {
        $product_id = (int)($_GET['id'] ?? 0);
        
        if ($product_id <= 0) {
            header('Location: index.php');
            exit;
        }
        
        $product = $this->model->getProductById($product_id);
        
        if (!$product) {
            header('Location: index.php');
            exit;
        }
        
        // Get all products for navigation
        $all_products = $this->model->getAllProducts();
        $user = $_SESSION['user'] ?? null;
        
        $this->view->showProductDetail($product, $all_products, $user);
    }
    
    private function showAccount() {
        if (!isset($_SESSION['user'])) {
            header('Location: index.php?action=signin');
            exit;
        }
        
        $user_id = (int)$_SESSION['user']['id'];
        $user = $this->model->getUserById($user_id);
        
        if (!$user) {
            header('Location: index.php');
            exit;
        }
        
        $this->view->showAccountManagement($user);
    }
    
    private function handleEditAccount() {
        if (!isset($_SESSION['user'])) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            exit;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Invalid request method']);
            exit;
        }
        
        $user_id = (int)$_SESSION['user']['id'];
        $name = trim($_POST['name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        
        header('Content-Type: application/json');
        
        // Validate required fields
        if (empty($name) || empty($username) || empty($email)) {
            echo json_encode(['success' => false, 'message' => 'Name, username, and email are required']);
            exit;
        }
        
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['success' => false, 'message' => 'Please enter a valid email address']);
            exit;
        }
        
        // Validate username format
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            echo json_encode(['success' => false, 'message' => 'Username can only contain letters, numbers, and underscores']);
            exit;
        }
        
        // Get current user data
        $current_user = $this->model->getUserById($user_id);
        if (!$current_user) {
            echo json_encode(['success' => false, 'message' => 'User not found']);
            exit;
        }
        
        // Check if email is being changed and if new email already exists
        if ($email !== $current_user['email']) {
            $existing_user = $this->model->getUserByEmail($email);
            if ($existing_user && $existing_user['id'] != $user_id) {
                echo json_encode(['success' => false, 'message' => 'Email already in use']);
                exit;
            }
        }
        
        // Check if username is being changed and if new username already exists
        if ($username !== $current_user['username']) {
            $existing_user = $this->model->getUserByUsername($username);
            if ($existing_user && $existing_user['id'] != $user_id) {
                echo json_encode(['success' => false, 'message' => 'Username already in use']);
                exit;
            }
        }
        
        // If password is being changed, verify current password
        $update_data = [
            'name' => htmlspecialchars($name, ENT_QUOTES, 'UTF-8'),
            'username' => htmlspecialchars($username, ENT_QUOTES, 'UTF-8'),
            'email' => filter_var($email, FILTER_SANITIZE_EMAIL)
        ];
        
        if (!empty($new_password)) {
            if (empty($current_password)) {
                echo json_encode(['success' => false, 'message' => 'Current password is required to change password']);
                exit;
            }
            
            if (!password_verify($current_password, $current_user['password'])) {
                echo json_encode(['success' => false, 'message' => 'Current password is incorrect']);
                exit;
            }
            
            if (strlen($new_password) < 6) {
                echo json_encode(['success' => false, 'message' => 'New password must be at least 6 characters long']);
                exit;
            }
            
            $update_data['password'] = $new_password;
        }
        
        if ($this->model->updateUser($user_id, $update_data)) {
            // Update session with new data
            $updated_user = $this->model->getUserById($user_id);
            $_SESSION['user'] = [
                'id' => $updated_user['id'],
                'name' => $updated_user['name'],
                'email' => $updated_user['email'],
                'username' => $updated_user['username'],
                'role' => $updated_user['role'] ?? 'fan'
            ];
            
            echo json_encode(['success' => true, 'message' => 'Account updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update account']);
        }
        exit;
    }
    
    private function handleDeleteAccount() {
        if (!isset($_SESSION['user'])) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            exit;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Invalid request method']);
            exit;
        }
        
        $user_id = (int)$_SESSION['user']['id'];
        $password = $_POST['password'] ?? '';
        
        header('Content-Type: application/json');
        
        if (empty($password)) {
            echo json_encode(['success' => false, 'message' => 'Password is required to delete account']);
            exit;
        }
        
        // Verify password
        $user = $this->model->getUserById($user_id);
        if (!$user || !password_verify($password, $user['password'])) {
            echo json_encode(['success' => false, 'message' => 'Incorrect password']);
            exit;
        }
        
        if ($this->model->deleteUser($user_id)) {
            // Destroy session
            session_destroy();
            echo json_encode(['success' => true, 'message' => 'Account deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to delete account']);
        }
        exit;
    }
}
?>