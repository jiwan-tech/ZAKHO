<?php
require_once '../controllers/ClubController.php';

$controller = new ClubController();
$controller->handleRequest();
?>